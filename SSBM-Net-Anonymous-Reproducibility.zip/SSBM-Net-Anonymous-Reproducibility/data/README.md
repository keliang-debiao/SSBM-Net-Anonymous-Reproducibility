# Data contract

Raw public datasets are intentionally excluded from the repository.

## KuaiRec source files

The adapter recognizes the provider files `big_matrix.csv`, `small_matrix.csv`, `item_categories.csv`, and `social_network.csv`. The interaction adapter prefers `big_matrix.csv` when both matrices are present. Column aliases are resolved inside `scripts/prepare_kuairec.py` and recorded in the output manifest.

## Yelp source files

The adapter reads the provider JSON-lines files:

- `yelp_academic_dataset_review.json`
- `yelp_academic_dataset_business.json`
- `yelp_academic_dataset_user.json`

Users are ranked by valid review count, the requested subset is retained, businesses without categories are removed, and friendship links are restricted to retained users.

## Common processed schema

### interactions.csv

| Column | Meaning |
|---|---|
| user_id | Anonymized user identifier from the provider data |
| item_id | Item or business identifier |
| timestamp | UTC timestamp or provider interaction order |
| signal | Observed interaction value used by the adapter |

### item_topics.csv

| Column | Meaning |
|---|---|
| item_id | Item identifier |
| topic_id | Category or topic identifier |
| weight | Topic membership weight; multi-category rows sum after profile aggregation |

### social_edges.csv

| Column | Meaning |
|---|---|
| source_user_id | Source user |
| target_user_id | Target user |

The downstream pipeline accepts CSV files only and does not require proprietary storage formats.

