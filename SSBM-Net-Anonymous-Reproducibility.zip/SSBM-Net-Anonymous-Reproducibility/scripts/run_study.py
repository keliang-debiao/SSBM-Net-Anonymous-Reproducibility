#!/usr/bin/env python3
"""Run internal and temporal SSBM-Net experiments for one dataset."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.config import load_config
from ssbm_net.pipeline import run_study


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    run_study(config, args.output_dir)


if __name__ == "__main__":
    main()

