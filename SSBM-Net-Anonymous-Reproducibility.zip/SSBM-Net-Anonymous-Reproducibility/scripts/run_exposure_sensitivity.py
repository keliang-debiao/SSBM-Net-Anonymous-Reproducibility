#!/usr/bin/env python3
"""Run formula-level and item-level exposure-responsiveness checks."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs
from ssbm_net.features import _profile, _topic_index, build_user_features
from ssbm_net.io import load_processed_dataset


def replace_dominant_topic_items(interactions, item_topics, ratio, seed, dominant_mass=0.80):
    """Replace a fixed history share with items outside each user's dominant topics."""
    topics, item_to_vec = _topic_index(item_topics)
    item_ids = np.asarray(sorted(item_to_vec), dtype=object)
    changed = interactions.copy()
    rng = np.random.default_rng(seed)
    ordered_groups = interactions.sort_values(
        ["user_id", "timestamp", "item_id"], kind="mergesort"
    ).groupby("user_id", sort=True)
    for _, group in ordered_groups:
        history = group["item_id"].astype(str).tolist()
        profile = _profile(history, item_to_vec, len(topics))
        order = np.argsort(profile)[::-1]
        stop = int(np.searchsorted(np.cumsum(profile[order]), dominant_mass, side="left"))
        dominant = set(order[: stop + 1].tolist())
        source_positions = [
            index for index in group.index
            if any(item_to_vec.get(str(changed.at[index, "item_id"]), np.zeros(len(topics)))[topic] > 0 for topic in dominant)
        ]
        candidates = [
            str(item) for item in item_ids
            if all(item_to_vec[str(item)][topic] <= 0 for topic in dominant)
        ]
        count = min(int(np.floor(len(group) * ratio)), len(source_positions))
        if count <= 0 or not candidates:
            continue
        selected_positions = rng.choice(source_positions, size=count, replace=False)
        replacements = rng.choice(candidates, size=count, replace=True)
        changed.loc[selected_positions, "item_id"] = replacements
    return changed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    interactions, topics, social = load_processed_dataset(args.processed_dir)
    features = build_user_features(interactions, topics, social)
    normalizer = BRSNormalizer().fit(features)
    normalized = normalizer.transform(features)
    before = compute_brs(normalized, PRIOR_WEIGHTS)
    rows = []
    for ratio in (0.10, 0.20, 0.30):
        modified = normalized.copy()
        for column in ("topic_concentration", "interest_convergence", "low_cross_topic_exposure"):
            modified[column] = modified[column] * (1.0 - ratio)
        after = compute_brs(modified, PRIOR_WEIGHTS)
        rows.append({"method": "formula_level", "ratio": ratio, "mean_brs_before": before.mean(), "mean_brs_after": after.mean(), "mean_brs_decrease": (before - after).mean()})
        replaced = replace_dominant_topic_items(interactions, topics, ratio, args.seed, dominant_mass=0.80)
        replaced_features = build_user_features(replaced, topics, social)
        replaced_normalized = normalizer.transform(replaced_features)
        replaced_after = compute_brs(replaced_normalized, PRIOR_WEIGHTS)
        rows.append({"method": "item_replacement", "ratio": ratio, "mean_brs_before": before.mean(), "mean_brs_after": replaced_after.mean(), "mean_brs_decrease": (before - replaced_after).mean()})
    pd.DataFrame(rows).to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
