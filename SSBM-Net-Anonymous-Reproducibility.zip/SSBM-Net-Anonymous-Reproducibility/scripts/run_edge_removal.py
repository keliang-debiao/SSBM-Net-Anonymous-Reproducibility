#!/usr/bin/env python3
"""Measure BRS robustness under progressive social-edge removal."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs
from ssbm_net.features import build_user_features
from ssbm_net.io import load_processed_dataset


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[2026, 42, 3407, 2024, 2025])
    args = parser.parse_args()
    interactions, topics, social = load_processed_dataset(args.processed_dir)
    baseline = build_user_features(interactions, topics, social)
    normalizer = BRSNormalizer().fit(baseline)
    rows = []
    for seed in args.seeds:
        rng = np.random.default_rng(seed)
        order = rng.permutation(len(social))
        for fraction in (0.10, 0.20, 0.30, 0.40, 0.50):
            keep = order[int(np.floor(len(order) * fraction)):]
            retained = social.iloc[keep].copy()
            features = build_user_features(interactions, topics, retained)
            normalized = normalizer.transform(features)
            brs = compute_brs(normalized, PRIOR_WEIGHTS)
            rows.append({
                "seed": seed,
                "edges_removed": fraction,
                "mean_brs": brs.mean(),
                "sd_brs": brs.std(ddof=1),
                "mean_social_homophily": features["social_homophily"].mean(),
            })
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)


if __name__ == "__main__":
    main()
