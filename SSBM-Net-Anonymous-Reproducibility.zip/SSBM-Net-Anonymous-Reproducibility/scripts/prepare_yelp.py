#!/usr/bin/env python3
"""Convert Yelp Open Dataset files to the common SSBM-Net schema."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.io import sha256_file, write_manifest


def read_json_lines(path, fields):
    rows = []
    with Path(path).open("r", encoding="utf-8") as handle:
        for line in handle:
            record = json.loads(line)
            rows.append({field: record.get(field) for field in fields})
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--max-users", type=int, default=5000)
    args = parser.parse_args()
    raw = Path(args.raw_dir)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    review_path = raw / "yelp_academic_dataset_review.json"
    business_path = raw / "yelp_academic_dataset_business.json"
    user_path = raw / "yelp_academic_dataset_user.json"
    for path in (review_path, business_path, user_path):
        if not path.exists():
            raise FileNotFoundError(path)

    businesses = read_json_lines(business_path, ["business_id", "categories"])
    businesses = businesses.dropna(subset=["business_id", "categories"])
    valid_businesses = set(businesses["business_id"].astype(str))

    reviews = read_json_lines(review_path, ["user_id", "business_id", "date", "stars"])
    reviews = reviews[reviews["business_id"].astype(str).isin(valid_businesses)].dropna(subset=["user_id", "business_id", "date"])
    selected_users = reviews.groupby("user_id").size().sort_values(ascending=False).head(args.max_users).index.astype(str)
    reviews = reviews[reviews["user_id"].astype(str).isin(set(selected_users))]
    interactions = pd.DataFrame({
        "user_id": reviews["user_id"].astype(str),
        "item_id": reviews["business_id"].astype(str),
        "timestamp": pd.to_datetime(reviews["date"], utc=True).astype("int64") // 10**9,
        "signal": reviews["stars"].astype(float),
    }).sort_values(["user_id", "timestamp", "item_id"])

    retained_items = set(interactions["item_id"])
    topic_rows = []
    for row in businesses[businesses["business_id"].astype(str).isin(retained_items)].itertuples(index=False):
        categories = [part.strip() for part in str(row.categories).split(",") if part.strip()]
        if categories:
            weight = 1.0 / len(categories)
            topic_rows.extend({"item_id": str(row.business_id), "topic_id": category, "weight": weight} for category in categories)
    item_topics = pd.DataFrame(topic_rows).drop_duplicates(["item_id", "topic_id"])

    users = read_json_lines(user_path, ["user_id", "friends"])
    retained_users = set(interactions["user_id"])
    edge_rows = []
    for row in users[users["user_id"].astype(str).isin(retained_users)].itertuples(index=False):
        source = str(row.user_id)
        friends = [] if pd.isna(row.friends) or str(row.friends).strip().lower() == "none" else str(row.friends).split(",")
        for friend in friends:
            target = friend.strip()
            if target in retained_users and source != target:
                edge_rows.append((source, target))
    social_edges = pd.DataFrame(edge_rows, columns=["source_user_id", "target_user_id"]).drop_duplicates()

    interactions.to_csv(output / "interactions.csv", index=False)
    item_topics.to_csv(output / "item_topics.csv", index=False)
    social_edges.to_csv(output / "social_edges.csv", index=False)
    write_manifest(output / "manifest.json", {
        "dataset": "yelp",
        "max_users": args.max_users,
        "source_files": {path.name: sha256_file(path) for path in (review_path, business_path, user_path)},
        "rows": {
            "interactions": len(interactions),
            "item_topics": len(item_topics),
            "social_edges": len(social_edges),
        },
    })


if __name__ == "__main__":
    main()

