#!/usr/bin/env python3
"""Run outcome-permutation controls for temporal criterion validity."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, COMPONENTS, compute_brs, high_risk_labels, high_risk_threshold
from ssbm_net.evaluation import binary_metrics, continuous_metrics
from ssbm_net.splits import split_users


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--permutations", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    run = Path(args.run_dir)
    matrix = pd.read_csv(run / "temporal_user_matrix.csv")
    weights_frame = pd.read_csv(run / "proxy_weights_by_seed.csv")
    selected = weights_frame[weights_frame["seed"] == args.seed]
    weights = (selected if len(selected) else weights_frame).loc[:, COMPONENTS].mean().to_numpy()
    weights = weights / weights.sum()
    groups = split_users(matrix["user_id"], 0.70, 0.10, 0.20, args.seed)
    train_mask = matrix["user_id"].astype(str).isin(set(groups["train"]))
    test_mask = matrix["user_id"].astype(str).isin(set(groups["test"]))
    normalizer = BRSNormalizer().fit(matrix[train_mask])
    score = compute_brs(normalizer.transform(matrix[test_mask]), weights).to_numpy()
    full_target = matrix["future_narrowing_score"].to_numpy()
    rng = np.random.default_rng(args.seed)
    rows = []
    for index in range(args.permutations):
        permuted = rng.permutation(full_target)
        train_target = permuted[train_mask.to_numpy()]
        test_target = permuted[test_mask.to_numpy()]
        cutoff = high_risk_threshold(train_target, 0.30)
        labels = high_risk_labels(test_target, cutoff)
        rows.append({"permutation": index, **continuous_metrics(test_target, score), **binary_metrics(labels, score)})
    pd.DataFrame(rows).to_csv(run / "permutation_control.csv", index=False)


if __name__ == "__main__":
    main()
