#!/usr/bin/env python3
"""Convert KuaiRec provider files to the common SSBM-Net schema."""

from __future__ import annotations

import argparse
import ast
from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.io import sha256_file, write_manifest


def choose_column(frame, candidates, required=True):
    for name in candidates:
        if name in frame.columns:
            return name
    if required:
        raise ValueError(f"No compatible column found among {candidates}")
    return None


def parse_categories(value):
    if pd.isna(value):
        return []
    if isinstance(value, (list, tuple)):
        return [str(x) for x in value]
    text = str(value).strip()
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, (list, tuple)):
            return [str(x) for x in parsed]
    except (ValueError, SyntaxError):
        pass
    return [part.strip() for part in text.replace("|", ",").split(",") if part.strip()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    raw = Path(args.raw_dir)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)

    matrix_path = raw / "big_matrix.csv"
    if not matrix_path.exists():
        matrix_path = raw / "small_matrix.csv"
    category_path = raw / "item_categories.csv"
    social_path = raw / "social_network.csv"
    for path in (matrix_path, category_path, social_path):
        if not path.exists():
            raise FileNotFoundError(path)

    matrix = pd.read_csv(matrix_path)
    user_col = choose_column(matrix, ["user_id", "userId", "user"])
    item_col = choose_column(matrix, ["video_id", "item_id", "itemId", "item"])
    time_col = choose_column(matrix, ["timestamp", "time", "date", "watch_time"], required=False)
    signal_col = choose_column(matrix, ["watch_ratio", "is_click", "signal", "play_time_ms"], required=False)
    interactions = pd.DataFrame({
        "user_id": matrix[user_col].astype(str),
        "item_id": matrix[item_col].astype(str),
        "timestamp": matrix[time_col] if time_col else matrix.groupby(user_col).cumcount(),
        "signal": matrix[signal_col].astype(float) if signal_col else 1.0,
    })
    interactions = interactions.dropna(subset=["user_id", "item_id"]).sort_values(["user_id", "timestamp", "item_id"])

    category = pd.read_csv(category_path)
    category_item = choose_column(category, ["video_id", "item_id", "itemId", "item"])
    category_col = choose_column(category, ["feat", "categories", "category", "topic"])
    topic_rows = []
    for row in category[[category_item, category_col]].itertuples(index=False):
        item = str(row[0])
        values = parse_categories(row[1])
        if not values:
            continue
        weight = 1.0 / len(values)
        topic_rows.extend({"item_id": item, "topic_id": topic, "weight": weight} for topic in values)
    item_topics = pd.DataFrame(topic_rows).drop_duplicates(["item_id", "topic_id"])

    social = pd.read_csv(social_path)
    source = choose_column(social, ["user_id", "source_user_id", "user", "src"])
    target = choose_column(social, ["friend_id", "target_user_id", "friend", "dst"])
    social_edges = pd.DataFrame({
        "source_user_id": social[source].astype(str),
        "target_user_id": social[target].astype(str),
    }).drop_duplicates()

    interactions.to_csv(output / "interactions.csv", index=False)
    item_topics.to_csv(output / "item_topics.csv", index=False)
    social_edges.to_csv(output / "social_edges.csv", index=False)
    write_manifest(output / "manifest.json", {
        "dataset": "kuairec",
        "source_files": {path.name: sha256_file(path) for path in (matrix_path, category_path, social_path)},
        "rows": {
            "interactions": len(interactions),
            "item_topics": len(item_topics),
            "social_edges": len(social_edges),
        },
    })


if __name__ == "__main__":
    main()

