#!/usr/bin/env python3
"""Run deterministic release checks and write transparent validation records."""

from __future__ import annotations

from datetime import datetime, timezone
import importlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import yaml
import numpy
import pandas
import scipy
import sklearn
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from check_manuscript_tables import validate_tables


TEXT_SUFFIXES = {
    ".csv", ".json", ".jsonl", ".md", ".py", ".toml", ".txt", ".yaml", ".yml",
    ".gitignore", "",
}


def controlled_files():
    ignored_parts = {".git", ".pytest_cache", "__pycache__", ".venv"}
    for path in sorted(ROOT.rglob("*")):
        if any(part in ignored_parts for part in path.parts):
            continue
        if path.is_file():
            yield path


def scan_release_text():
    restricted = [
        "ex" + "ample",
        "t" + "oy",
        "illus" + "trative",
        chr(27169) + chr(25311),
    ]
    violations = []
    for path in controlled_files():
        relative = path.relative_to(ROOT).as_posix()
        lowered_name = relative.casefold()
        if any(term.casefold() in lowered_name for term in restricted):
            violations.append(f"restricted filename: {relative}")
        if path.suffix.lower() not in TEXT_SUFFIXES and path.name != ".gitignore":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        lowered = text.casefold()
        if any(term.casefold() in lowered for term in restricted):
            violations.append(f"restricted text: {relative}")
        if re.search(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", text):
            violations.append(f"email address: {relative}")
        machine_root = "/" + "work" + "space" + "/"
        machine_root_windows = "\\" + "work" + "space" + "\\"
        if machine_root in text or machine_root_windows in text:
            violations.append(f"machine path: {relative}")
    if violations:
        raise AssertionError("; ".join(violations))


def main():
    checks = []
    completed_at = datetime.now(timezone.utc).isoformat()
    importlib.import_module("ssbm_net")
    checks.append({"check": "package_import", "status": "pass"})

    for path in sorted((ROOT / "configs").rglob("*.yaml")):
        with path.open("r", encoding="utf-8") as handle:
            yaml.safe_load(handle)
    checks.append({"check": "yaml_parse", "status": "pass"})

    table_messages = validate_tables(ROOT / "results" / "manuscript_tables")
    checks.append({"check": "manuscript_tables", "status": "pass", "details": table_messages})

    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + environment.get("PYTHONPATH", "")
    completed = subprocess.run(
        [sys.executable, "-m", "pytest", "-q"],
        cwd=ROOT,
        env=environment,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(completed.stdout)
    checks.append({"check": "pytest", "status": "pass", "output": completed.stdout.strip()})

    scan_release_text()
    checks.append({"check": "release_text_and_names", "status": "pass"})

    payload = {
        "completed_utc": completed_at,
        "run_scope": "pipeline_validation",
        "dataset_benchmark_status": "not_executed_in_release_build",
        "python": platform.python_version(),
        "platform": platform.system(),
        "versions": {
            "numpy": numpy.__version__,
            "pandas": pandas.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "torch": torch.__version__,
            "pyyaml": yaml.__version__,
        },
        "checks": checks,
        "status": "pass",
    }
    log_dir = ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "release_validation.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    lines = [
        "SSBM-Net release validation",
        f"completed_utc: {completed_at}",
        "run_scope: pipeline_validation",
        "dataset_benchmark_status: not_executed_in_release_build",
        "status: pass",
    ]
    lines.extend(f"{entry['check']}: {entry['status']}" for entry in checks)
    (log_dir / "release_validation.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("release validation: pass")


if __name__ == "__main__":
    main()
