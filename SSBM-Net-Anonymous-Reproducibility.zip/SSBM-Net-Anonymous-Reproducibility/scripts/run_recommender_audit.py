#!/usr/bin/env python3
"""Train recommendation generators and audit their top-20 lists."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.audit import audit_rankings_with_brs, evaluate_rankings, item_topic_matrix
from ssbm_net.config import load_config, save_yaml_snapshot
from ssbm_net.features import user_topic_profiles
from ssbm_net.io import JsonlLogger, load_processed_dataset
from ssbm_net.recommenders import (
    BPRMFRecommender,
    DistributionCalibratedReranker,
    LightGCNRecommender,
    PopularityRecommender,
    SASRecRecommender,
    XQuADReranker,
)
from ssbm_net.recommenders.base import build_candidate_sets
from ssbm_net.splits import recommendation_split


def make_model(name, cfg, seed):
    common = dict(
        dimension=cfg["embedding_dim"], learning_rate=cfg["learning_rate"],
        weight_decay=cfg["weight_decay"], batch_size=cfg["batch_size"],
        epochs=cfg["max_epochs"], seed=seed,
        patience=cfg["patience"], validation_candidate_size=cfg["candidate_size"],
        device="cuda" if __import__("torch").cuda.is_available() else "cpu",
    )
    if name == "popularity":
        return PopularityRecommender()
    if name == "bpr_mf":
        return BPRMFRecommender(**common)
    if name == "lightgcn":
        return LightGCNRecommender(**common, layers=cfg["lightgcn_layers"])
    if name == "ips_lightgcn":
        return LightGCNRecommender(**common, layers=cfg["lightgcn_layers"], ips_clip=cfg["ips_clip"])
    if name == "sasrec":
        return SASRecRecommender(
            dimension=cfg["embedding_dim"], blocks=cfg["sasrec_blocks"], heads=cfg["sasrec_heads"],
            dropout=cfg["sasrec_dropout"], max_length=cfg["sasrec_max_length"],
            learning_rate=cfg["learning_rate"], weight_decay=cfg["weight_decay"],
            batch_size=min(cfg["batch_size"], 512), epochs=cfg["max_epochs"], seed=seed,
            patience=cfg["patience"], validation_candidate_size=cfg["candidate_size"],
            device=common["device"],
        )
    raise KeyError(name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    save_yaml_snapshot(config, output / "resolved_config.yaml")
    logger = JsonlLogger(output / "run.jsonl")
    interactions, item_topics, social_edges = load_processed_dataset(config["processed_dir"])
    train, validation, test = recommendation_split(interactions)
    rec_cfg = config["recommendation"]
    utility_rows, exposure_rows = [], []
    for seed in config["seeds"]:
        candidates = build_candidate_sets(train, test, rec_cfg["candidate_size"], seed)
        _, profiles = user_topic_profiles(train, item_topics)
        for model_name in ["popularity", "bpr_mf", "lightgcn", "sasrec", "ips_lightgcn"]:
            model = make_model(model_name, rec_cfg, seed)
            if model_name == "popularity":
                model.fit(train)
            else:
                model.fit(train, validation)
            rankings, positives = {}, {}
            for user, (positive, items) in candidates.items():
                rankings[user] = model.rank(user, items)[: rec_cfg["top_k"]]
                positives[user] = positive
            utility_rows.append({"seed": seed, "model": model_name, **evaluate_rankings(rankings, positives, rec_cfg["top_k"])})
            exposure = audit_rankings_with_brs(
                rankings, train, item_topics, social_edges,
                high_fraction=config["measurement"]["high_risk_fraction"],
                dominant_topic_mass=config["measurement"]["dominant_topic_mass"],
                social_missing_value=config["measurement"]["social_missing_value"],
            )
            eligible = exposure[exposure["eligible_transition"]]
            summary = exposure.drop(columns=["user_id", "eligible_transition", "high_risk_transition"]).mean().to_dict()
            summary["high_risk_transition"] = float(eligible["high_risk_transition"].mean()) if len(eligible) else 0.0
            exposure_rows.append({"seed": seed, "model": model_name, **summary})

            if model_name == "lightgcn":
                calibrated, diversified = {}, {}
                cal = DistributionCalibratedReranker(rec_cfg["calibrated_js_weight"])
                xquad = XQuADReranker(rec_cfg["xquad_weight"])
                for user, (positive, items) in candidates.items():
                    scores = model.score(user, items)
                    _, vectors = item_topic_matrix(items, item_topics)
                    profile = profiles.get(user, np.zeros(vectors.shape[1]))
                    calibrated[user] = cal.rerank(items, scores, vectors, profile, rec_cfg["top_k"])
                    diversified[user] = xquad.rerank(items, scores, vectors, rec_cfg["top_k"])
                for name, ranking in [("calibrated_lightgcn", calibrated), ("xquad_lightgcn", diversified)]:
                    utility_rows.append({"seed": seed, "model": name, **evaluate_rankings(ranking, positives, rec_cfg["top_k"])})
                    exposure = audit_rankings_with_brs(
                        ranking, train, item_topics, social_edges,
                        high_fraction=config["measurement"]["high_risk_fraction"],
                        dominant_topic_mass=config["measurement"]["dominant_topic_mass"],
                        social_missing_value=config["measurement"]["social_missing_value"],
                    )
                    eligible = exposure[exposure["eligible_transition"]]
                    summary = exposure.drop(columns=["user_id", "eligible_transition", "high_risk_transition"]).mean().to_dict()
                    summary["high_risk_transition"] = float(eligible["high_risk_transition"].mean()) if len(eligible) else 0.0
                    exposure_rows.append({"seed": seed, "model": name, **summary})
            logger.write("model_complete", seed=seed, model=model_name)
    pd.DataFrame(utility_rows).to_csv(output / "utility_by_seed.csv", index=False)
    pd.DataFrame(exposure_rows).to_csv(output / "exposure_by_seed.csv", index=False)
    logger.write("run_complete", rows=len(utility_rows))


if __name__ == "__main__":
    main()
