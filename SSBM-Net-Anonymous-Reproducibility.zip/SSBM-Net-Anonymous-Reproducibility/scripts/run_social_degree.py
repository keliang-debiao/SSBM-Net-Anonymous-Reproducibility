#!/usr/bin/env python3
"""Evaluate temporal criterion performance across observed social-degree strata."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, COMPONENTS, high_risk_labels, high_risk_threshold
from ssbm_net.calibration import apply_temperature, fit_temperature, logits_from_probabilities
from ssbm_net.evaluation import binary_metrics
from ssbm_net.social import enhance_with_social_neighborhood
from ssbm_net.splits import split_users


def degree_label(dataset, degree):
    if dataset == "kuairec":
        return "0" if degree == 0 else "1" if degree == 1 else "2-3" if degree <= 3 else ">=4"
    return "0" if degree == 0 else "1-10" if degree <= 10 else "11-50" if degree <= 50 else ">50"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--social-edges", required=True)
    parser.add_argument("--dataset", choices=["kuairec", "yelp"], required=True)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    run = Path(args.run_dir)
    frame = pd.read_csv(run / "temporal_user_matrix.csv")
    edges = pd.read_csv(args.social_edges)
    groups = split_users(frame["user_id"], 0.70, 0.10, 0.20, args.seed)
    train_mask = frame["user_id"].astype(str).isin(set(groups["train"]))
    validation_mask = frame["user_id"].astype(str).isin(set(groups["validation"]))
    test_mask = frame["user_id"].astype(str).isin(set(groups["test"]))
    normalizer = BRSNormalizer().fit(frame[train_mask])
    enhanced = enhance_with_social_neighborhood(normalizer.transform(frame), edges).reset_index(drop=True)
    cutoff = high_risk_threshold(frame.loc[train_mask, "future_narrowing_score"], 0.30)
    labels = high_risk_labels(enhanced["future_narrowing_score"], cutoff)
    train_idx = np.flatnonzero(train_mask.to_numpy())
    validation_idx = np.flatnonzero(validation_mask.to_numpy())
    test_idx = np.flatnonzero(test_mask.to_numpy())
    base_columns = list(COMPONENTS)
    neighbor_columns = [f"neighbor_{name}" for name in COMPONENTS]
    variants = {
        "base": base_columns,
        "neighbor_mean": base_columns + neighbor_columns,
        "availability": base_columns + neighbor_columns + ["social_available"],
    }
    rows = []
    for name, columns in variants.items():
        model = LogisticRegression(max_iter=2000, class_weight="balanced", random_state=args.seed)
        model.fit(enhanced.loc[train_idx, columns], labels[train_idx])
        validation_probability = model.predict_proba(enhanced.loc[validation_idx, columns])[:, 1]
        temperature = fit_temperature(logits_from_probabilities(validation_probability), labels[validation_idx])
        test_probability = apply_temperature(logits_from_probabilities(model.predict_proba(enhanced.loc[test_idx, columns])[:, 1]), temperature)
        test = enhanced.loc[test_idx].copy()
        test["label"] = labels[test_idx]
        test["probability"] = test_probability
        test["degree_stratum"] = [degree_label(args.dataset, int(value)) for value in test["social_degree"]]
        for stratum, group in test.groupby("degree_stratum", sort=True):
            if group["label"].nunique() < 2:
                continue
            rows.append({"dataset": args.dataset, "degree": stratum, "users": len(group), "variant": name,
                         **binary_metrics(group["label"], group["probability"])})
    pd.DataFrame(rows).to_csv(run / "social_degree_metrics.csv", index=False)


if __name__ == "__main__":
    main()
