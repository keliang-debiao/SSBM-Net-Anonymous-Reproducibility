#!/usr/bin/env python3
"""Create BRS-group profiles and component-rank correlations."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs
from ssbm_net.features import COMPONENT_COLUMNS, build_user_features
from ssbm_net.io import load_processed_dataset


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processed-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    interactions, topics, social = load_processed_dataset(args.processed_dir)
    raw = build_user_features(interactions, topics, social)
    normalized = BRSNormalizer().fit_transform(raw)
    normalized["brs"] = compute_brs(normalized, PRIOR_WEIGHTS)
    lower, upper = normalized["brs"].quantile([0.30, 0.70])
    normalized["group"] = pd.cut(
        normalized["brs"],
        bins=[float("-inf"), lower, upper, float("inf")],
        labels=["low", "middle", "high"],
        include_lowest=True,
    )
    aggregation = {"n": ("user_id", "size"), "brs": ("brs", "mean")}
    aggregation.update({column: (column, "mean") for column in COMPONENT_COLUMNS})
    groups = normalized.groupby("group", observed=True).agg(**aggregation).reset_index()
    correlations = []
    for column in COMPONENT_COLUMNS:
        statistic = spearmanr(normalized[column], normalized["brs"])
        correlations.append({"component": column, "spearman_rho": statistic.statistic, "p_value": statistic.pvalue})
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    groups.to_csv(output / "brs_group_profiles.csv", index=False)
    pd.DataFrame(correlations).to_csv(output / "component_correlations.csv", index=False)


if __name__ == "__main__":
    main()
