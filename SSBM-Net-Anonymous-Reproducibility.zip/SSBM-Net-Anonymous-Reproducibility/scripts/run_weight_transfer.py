#!/usr/bin/env python3
"""Evaluate dataset-specific, transferred, and pooled BRS weights."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, COMPONENTS, PRIOR_WEIGHTS, compute_brs, high_risk_labels, high_risk_threshold
from ssbm_net.evaluation import binary_metrics, continuous_metrics
from ssbm_net.splits import split_users


def load_run(path):
    path = Path(path)
    matrix = pd.read_csv(path / "temporal_user_matrix.csv")
    weights = pd.read_csv(path / "proxy_weights_by_seed.csv")
    return matrix, weights


def top_overlap(left, right, fraction=0.30):
    count = max(1, int(np.ceil(len(left) * fraction)))
    left_top = set(np.argsort(np.asarray(left))[-count:])
    right_top = set(np.argsort(np.asarray(right))[-count:])
    return len(left_top & right_top) / count


def weight_for_seed(frame, seed):
    selected = frame[frame["seed"] == seed]
    if selected.empty:
        selected = frame
    weights = selected.loc[:, COMPONENTS].mean().to_numpy(dtype=float)
    return weights / weights.sum()


def evaluate(train_raw, test_raw, weights, reference_score, source):
    normalizer = BRSNormalizer().fit(train_raw)
    test = normalizer.transform(test_raw)
    score = compute_brs(test, weights)
    threshold = high_risk_threshold(train_raw["future_narrowing_score"], 0.30)
    labels = high_risk_labels(test_raw["future_narrowing_score"], threshold)
    return {
        "weight_source": source,
        **continuous_metrics(test_raw["future_narrowing_score"], score),
        **binary_metrics(labels, score),
        "top30_overlap": top_overlap(reference_score, score),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kuairec-run", required=True)
    parser.add_argument("--yelp-run", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[2026, 42, 3407, 2024, 2025])
    args = parser.parse_args()
    kuairec, kw = load_run(args.kuairec_run)
    yelp, yw = load_run(args.yelp_run)
    rows = []
    for target_name, target, own_frame, transfer_frame in [
        ("kuairec", kuairec, kw, yw), ("yelp", yelp, yw, kw)
    ]:
        for seed in args.seeds:
            groups = split_users(target["user_id"], 0.70, 0.10, 0.20, seed)
            train = target[target["user_id"].astype(str).isin(set(groups["train"]))].copy()
            test = target[target["user_id"].astype(str).isin(set(groups["test"]))].copy()
            normalizer = BRSNormalizer().fit(train)
            normalized_test = normalizer.transform(test)
            own = weight_for_seed(own_frame, seed)
            transferred = weight_for_seed(transfer_frame, seed)
            pooled = (own + transferred) / 2.0
            reference = compute_brs(normalized_test, own)
            sources = [
                ("predefined_prior", PRIOR_WEIGHTS),
                ("equal", np.ones(len(COMPONENTS))),
                ("dataset_specific", own),
                ("transferred", transferred),
                ("pooled", pooled),
            ]
            for source, weights in sources:
                rows.append({
                    "target_dataset": target_name,
                    "seed": seed,
                    **evaluate(train, test, weights, reference, source),
                })
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / "weight_transfer_metrics.csv", index=False)


if __name__ == "__main__":
    main()
