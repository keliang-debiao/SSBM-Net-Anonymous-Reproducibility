#!/usr/bin/env python3
"""Compare probability-calibration strategies on the internal task."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs, high_risk_labels, high_risk_threshold
from ssbm_net.calibration import apply_temperature, fit_temperature, logits_from_probabilities
from ssbm_net.config import load_config
from ssbm_net.evaluation import binary_metrics
from ssbm_net.features import COMPONENT_COLUMNS, build_user_features
from ssbm_net.io import load_processed_dataset
from ssbm_net.models import make_classifier
from ssbm_net.social import enhance_with_social_neighborhood
from ssbm_net.splits import split_users


def subset(frame, users):
    return frame[frame["user_id"].astype(str).isin(set(map(str, users)))].copy()


def matrix(frame):
    columns = list(COMPONENT_COLUMNS) + [f"neighbor_{name}" for name in COMPONENT_COLUMNS] + ["social_available"]
    return frame[columns].to_numpy(dtype=float)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    interactions, topics, social = load_processed_dataset(config["processed_dir"])
    raw = build_user_features(interactions, topics, social)
    rows = []
    for seed in config["seeds"]:
        groups = split_users(raw.user_id, 0.70, 0.10, 0.20, seed)
        train_raw, valid_raw, test_raw = (subset(raw, groups[name]) for name in ("train", "validation", "test"))
        normalizer = BRSNormalizer().fit(train_raw)
        train, valid, test = map(normalizer.transform, (train_raw, valid_raw, test_raw))
        cutoff = high_risk_threshold(compute_brs(train, PRIOR_WEIGHTS), config["measurement"]["high_risk_fraction"])
        train_y = high_risk_labels(compute_brs(train, PRIOR_WEIGHTS), cutoff)
        valid_y = high_risk_labels(compute_brs(valid, PRIOR_WEIGHTS), cutoff)
        test_y = high_risk_labels(compute_brs(test, PRIOR_WEIGHTS), cutoff)
        train, valid, test = (
            enhance_with_social_neighborhood(frame, social) for frame in (train, valid, test)
        )
        validation_members, test_members, individually_scaled = [], [], []
        for member in range(config["calibration"]["ensemble_members"]):
            model = make_classifier("mlp", seed + member).fit(matrix(train), train_y)
            valid_probability = model.predict_proba(matrix(valid))[:, 1]
            test_probability = model.predict_proba(matrix(test))[:, 1]
            validation_members.append(valid_probability)
            test_members.append(test_probability)
            temperature = fit_temperature(logits_from_probabilities(valid_probability), valid_y)
            individually_scaled.append(apply_temperature(logits_from_probabilities(test_probability), temperature))
        validation_ensemble = np.mean(validation_members, axis=0)
        test_ensemble = np.mean(test_members, axis=0)
        platt = LogisticRegression(max_iter=2000, random_state=seed).fit(
            logits_from_probabilities(validation_ensemble).reshape(-1, 1), valid_y
        )
        platt_probability = platt.predict_proba(
            logits_from_probabilities(test_ensemble).reshape(-1, 1)
        )[:, 1]
        isotonic = IsotonicRegression(out_of_bounds="clip").fit(validation_ensemble, valid_y)
        isotonic_probability = isotonic.predict(test_ensemble)
        temperature = fit_temperature(logits_from_probabilities(validation_ensemble), valid_y)
        temperature_probability = apply_temperature(logits_from_probabilities(test_ensemble), temperature)
        strategies = {
            "uncalibrated": test_members[0],
            "ensemble_only": test_ensemble,
            "platt": platt_probability,
            "isotonic": isotonic_probability,
            "temperature": temperature_probability,
            "calibrated_ensemble": np.mean(individually_scaled, axis=0),
        }
        for method, probability in strategies.items():
            rows.append({
                "seed": seed,
                "method": method,
                **binary_metrics(test_y, probability, bins=config["calibration"]["ece_bins"]),
            })
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)


if __name__ == "__main__":
    main()
