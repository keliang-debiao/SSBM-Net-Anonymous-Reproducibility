#!/usr/bin/env python3
"""Evaluate BRS-rank stability under prespecified weight changes."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, COMPONENTS, PRIOR_WEIGHTS, compute_brs, validate_weights


def top_overlap(left, right, fraction=0.30):
    count = max(1, int(np.ceil(len(left) * fraction)))
    left_top = set(np.argsort(np.asarray(left))[-count:])
    right_top = set(np.argsort(np.asarray(right))[-count:])
    return len(left_top & right_top) / count


def evaluate(name, score, reference):
    return {
        "weights": name,
        "spearman_rho": spearmanr(reference, score).statistic,
        "top30_overlap": top_overlap(reference, score),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--draws", type=int, default=200)
    parser.add_argument("--seed", type=int, default=2026)
    args = parser.parse_args()
    run = Path(args.run_dir)
    matrix = pd.read_csv(run / "temporal_user_matrix.csv")
    normalized = BRSNormalizer().fit_transform(matrix)
    reference = compute_brs(normalized, PRIOR_WEIGHTS).to_numpy()
    learned = pd.read_csv(run / "proxy_weights_by_seed.csv").loc[:, COMPONENTS].mean().to_numpy()
    rows = [evaluate("equal", compute_brs(normalized, np.ones(len(COMPONENTS))), reference)]
    rng = np.random.default_rng(args.seed)
    for level in (0.10, 0.20):
        measurements = []
        overlaps = []
        for _ in range(args.draws):
            factors = rng.choice([1.0 - level, 1.0 + level], size=len(COMPONENTS))
            score = compute_brs(normalized, validate_weights(PRIOR_WEIGHTS * factors)).to_numpy()
            measurements.append(spearmanr(reference, score).statistic)
            overlaps.append(top_overlap(reference, score))
        rows.append({
            "weights": f"independent_{int(level * 100)}pct",
            "spearman_rho": float(np.mean(measurements)),
            "top30_overlap": float(np.mean(overlaps)),
        })
    rows.append(evaluate("proxy_learned", compute_brs(normalized, learned), reference))
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)


if __name__ == "__main__":
    main()
