#!/usr/bin/env python3
"""Validate the machine-readable result matrices reported in the manuscript."""

from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd


EXPECTED_ROWS = {
    "table04_internal_consistency.csv": 14,
    "table05_temporal_continuous.csv": 8,
    "table06_temporal_binary.csv": 14,
    "table07_permutation_control.csv": 4,
    "table08_component_ablation.csv": 12,
    "table09_social_degree.csv": 24,
    "table10_brs_weights.csv": 4,
    "table11_weight_transfer.csv": 10,
    "table12_recommender_utility.csv": 14,
    "table13_recommender_audit.csv": 14,
    "table14_exposure_responsiveness.csv": 12,
    "table15_brs_group_profiles.csv": 6,
    "table16_component_correlations.csv": 12,
    "table17_edge_removal.csv": 10,
    "table18_weight_sensitivity.csv": 5,
    "table19_threshold_sensitivity.csv": 8,
    "table20_calibration_comparison.csv": 12,
}

WEIGHT_COLUMNS = [
    "semantic_homogeneity",
    "social_homophily",
    "topic_concentration",
    "interest_convergence",
    "low_cross_topic_exposure",
    "evidence_insufficiency",
]


def validate_tables(root: Path) -> list[str]:
    messages = []
    loaded = {}
    for filename, expected_rows in EXPECTED_ROWS.items():
        path = root / filename
        if not path.is_file():
            raise AssertionError(f"Missing result matrix: {filename}")
        frame = pd.read_csv(path)
        if len(frame) != expected_rows:
            raise AssertionError(f"{filename}: expected {expected_rows} rows, found {len(frame)}")
        if frame.columns.duplicated().any():
            raise AssertionError(f"{filename}: duplicate columns")
        loaded[filename] = frame
        messages.append(f"{filename}: {len(frame)} rows")

    weights = loaded["table10_brs_weights.csv"]
    if not set(WEIGHT_COLUMNS).issubset(weights.columns):
        raise AssertionError("BRS weight matrix has incomplete component columns")
    sums = weights[WEIGHT_COLUMNS].sum(axis=1).to_numpy(dtype=float)
    if not np.allclose(sums, 1.0, atol=1e-12):
        raise AssertionError("BRS weights must sum to one")

    expected_users = {"KuaiRec": 1411, "Yelp": 5000}
    social = loaded["table09_social_degree.csv"]
    unique_strata = social[["dataset", "degree", "users"]].drop_duplicates()
    totals = unique_strata.groupby("dataset")["users"].sum().to_dict()
    if totals != expected_users:
        raise AssertionError(f"Social-degree user totals are inconsistent: {totals}")

    groups = loaded["table15_brs_group_profiles.csv"].groupby("dataset")["n"].sum().to_dict()
    if groups != expected_users:
        raise AssertionError(f"BRS-group user totals are inconsistent: {groups}")

    for filename, frame in loaded.items():
        for column in frame.select_dtypes(include=[np.number]).columns:
            values = frame[column].dropna().to_numpy(dtype=float)
            if not np.isfinite(values).all():
                raise AssertionError(f"{filename}: non-finite value in {column}")
            if column.endswith("_sd") and np.any(values < 0):
                raise AssertionError(f"{filename}: negative standard deviation in {column}")
            bounded = any(token in column for token in (
                "accuracy", "f1", "auc", "brier", "ece", "overlap", "transition",
                "entropy", "coverage", "ratio", "js_divergence",
            ))
            if bounded and np.any((values < 0) | (values > 1)):
                raise AssertionError(f"{filename}: out-of-range value in {column}")
    messages.append("cross-table consistency: pass")
    return messages


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--table-dir",
        default=str(Path(__file__).resolve().parents[1] / "results" / "manuscript_tables"),
    )
    args = parser.parse_args()
    for message in validate_tables(Path(args.table_dir)):
        print(message)


if __name__ == "__main__":
    main()
