#!/usr/bin/env python3
"""Run leave-one-component-out internal BRS-label analyses."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs, high_risk_labels, high_risk_threshold
from ssbm_net.config import load_config
from ssbm_net.evaluation import binary_metrics
from ssbm_net.features import COMPONENT_COLUMNS, build_user_features
from ssbm_net.io import load_processed_dataset
from ssbm_net.models import CalibratedEnsemble
from ssbm_net.splits import split_users


def subset(frame, users):
    return frame[frame["user_id"].astype(str).isin(set(map(str, users)))].copy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    interactions, topics, social = load_processed_dataset(config["processed_dir"])
    raw = build_user_features(interactions, topics, social)
    rows = []
    for seed in config["seeds"]:
        groups = split_users(raw.user_id, 0.70, 0.10, 0.20, seed)
        train_raw, valid_raw, test_raw = (subset(raw, groups[name]) for name in ("train", "validation", "test"))
        normalizer = BRSNormalizer().fit(train_raw)
        train, valid, test = map(normalizer.transform, (train_raw, valid_raw, test_raw))
        train_brs = compute_brs(train, PRIOR_WEIGHTS)
        cutoff = high_risk_threshold(train_brs, config["measurement"]["high_risk_fraction"])
        train_y = high_risk_labels(train_brs, cutoff)
        valid_y = high_risk_labels(compute_brs(valid, PRIOR_WEIGHTS), cutoff)
        test_y = high_risk_labels(compute_brs(test, PRIOR_WEIGHTS), cutoff)
        for removed in COMPONENT_COLUMNS:
            columns = [column for column in COMPONENT_COLUMNS if column != removed]
            model = CalibratedEnsemble(
                members=config["calibration"]["ensemble_members"], seed=seed
            ).fit(train[columns], train_y, valid[columns], valid_y)
            probability = model.predict_proba(test[columns])[:, 1]
            rows.append({
                "seed": seed,
                "removed_component": removed,
                **binary_metrics(test_y, probability, bins=config["calibration"]["ece_bins"]),
            })
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)


if __name__ == "__main__":
    main()
