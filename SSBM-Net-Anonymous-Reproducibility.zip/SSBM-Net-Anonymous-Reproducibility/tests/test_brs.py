import numpy as np

from ssbm_net.brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs, learn_proxy_weights
from ssbm_net.features import build_user_features


def test_prior_weights_and_score_bounds(fixture_data):
    interactions, topics, social = fixture_data
    raw = build_user_features(interactions, topics, social)
    normalized = BRSNormalizer().fit_transform(raw)
    score = compute_brs(normalized, PRIOR_WEIGHTS)
    assert np.isclose(PRIOR_WEIGHTS.sum(), 1.0)
    assert (score >= 0).all() and (score <= 1).all()


def test_proxy_weights_are_nonnegative_and_normalized(fixture_data):
    interactions, topics, social = fixture_data
    raw = build_user_features(interactions, topics, social)
    normalized = BRSNormalizer().fit_transform(raw)
    target = 0.6 * normalized.topic_concentration + 0.4 * normalized.low_cross_topic_exposure
    learned = learn_proxy_weights(normalized, target)
    assert np.all(learned >= 0)
    assert np.isclose(learned.sum(), 1.0)


def test_training_extrema_are_frozen(fixture_data):
    interactions, topics, social = fixture_data
    raw = build_user_features(interactions, topics, social)
    train, heldout = raw.iloc[:40], raw.iloc[40:].copy()
    normalizer = BRSNormalizer().fit(train)
    train_minimum = normalizer.minimum.copy()
    heldout.loc[:, "topic_concentration"] = heldout.topic_concentration + 10.0
    normalizer.transform(heldout)
    assert np.array_equal(normalizer.minimum, train_minimum)

