import numpy as np

from ssbm_net.splits import chronological_user_split
from ssbm_net.temporal import compute_future_outcomes, future_narrowing_score


def test_temporal_periods_do_not_overlap(fixture_data):
    interactions, topics, social = fixture_data
    early, future = chronological_user_split(interactions, 0.70)
    for user in interactions.user_id.unique():
        early_times = early[early.user_id == user].timestamp
        future_times = future[future.user_id == user].timestamp
        assert early_times.max() < future_times.min()


def test_future_score_is_bounded(fixture_data):
    interactions, topics, social = fixture_data
    early, future = chronological_user_split(interactions, 0.70)
    outcomes = compute_future_outcomes(early, future, topics, early)
    score = future_narrowing_score(outcomes)
    assert np.isfinite(score).all()
    assert (score >= 0).all() and (score <= 1).all()

