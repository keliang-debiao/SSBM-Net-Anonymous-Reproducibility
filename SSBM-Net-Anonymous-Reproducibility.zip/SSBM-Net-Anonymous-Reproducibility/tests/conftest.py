from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def fixture_data():
    rng = np.random.default_rng(2026)
    users = [f"u{i:03d}" for i in range(60)]
    items = [f"i{i:03d}" for i in range(30)]
    item_topics = pd.DataFrame({
        "item_id": items,
        "topic_id": [f"t{i % 6}" for i in range(len(items))],
        "weight": 1.0,
    })
    interactions = []
    for user_index, user in enumerate(users):
        dominant = user_index % 6
        for time in range(18):
            if time < 12:
                candidates = [i for i in range(30) if i % 6 in {dominant, (dominant + 1) % 6, (dominant + 2) % 6}]
            else:
                candidates = [i for i in range(30) if i % 6 == dominant]
            item = items[int(rng.choice(candidates))]
            interactions.append((user, item, time, 1.0))
    interactions = pd.DataFrame(interactions, columns=["user_id", "item_id", "timestamp", "signal"])
    edges = []
    for index in range(6, len(users) - 1):
        edges.append((users[index], users[index + 1]))
    social = pd.DataFrame(edges, columns=["source_user_id", "target_user_id"])
    return interactions, item_topics, social
