import pandas as pd

from ssbm_net.pipeline import run_study


def test_primary_pipeline_writes_expected_artifacts(fixture_data, tmp_path):
    interactions, topics, social = fixture_data
    processed = tmp_path / "processed"
    processed.mkdir()
    interactions.to_csv(processed / "interactions.csv", index=False)
    topics.to_csv(processed / "item_topics.csv", index=False)
    social.to_csv(processed / "social_edges.csv", index=False)
    config = {
        "processed_dir": str(processed),
        "seeds": [2026],
        "split": {
            "user_train": 0.70,
            "user_validation": 0.10,
            "user_test": 0.20,
            "history_early": 0.70,
            "component_early": 0.50,
        },
        "measurement": {
            "dominant_topic_mass": 0.80,
            "social_missing_value": 0.50,
            "high_risk_fraction": 0.30,
            "proxy_ridge": 0.001,
        },
        "calibration": {"ensemble_members": 1, "ece_bins": 10},
    }
    output = tmp_path / "run"
    summary = run_study(config, output)
    assert summary["internal_rows"] == 7
    assert summary["temporal_rows"] == 7
    expected = {
        "internal_metrics_by_seed.csv",
        "temporal_metrics_by_seed.csv",
        "temporal_continuous_by_seed.csv",
        "proxy_weights_by_seed.csv",
        "temporal_user_matrix.csv",
        "resolved_config.yaml",
        "run.jsonl",
    }
    assert expected.issubset({path.name for path in output.iterdir()})
    assert len(pd.read_csv(output / "temporal_continuous_by_seed.csv")) == 4
