import numpy as np

from ssbm_net.features import COMPONENT_COLUMNS, build_user_features


def test_six_components_and_bounds(fixture_data):
    interactions, topics, social = fixture_data
    features = build_user_features(interactions, topics, social)
    assert len(features) == interactions.user_id.nunique()
    assert set(COMPONENT_COLUMNS).issubset(features.columns)
    for column in COMPONENT_COLUMNS[:-1]:
        assert np.isfinite(features[column]).all()
        assert (features[column] >= 0).all()
        assert (features[column] <= 1).all()
    assert (features["evidence_insufficiency"] > 0).all()


def test_missing_social_evidence_is_explicit(fixture_data):
    interactions, topics, social = fixture_data
    features = build_user_features(interactions, topics, social, social_missing_value=0.5)
    missing = features[features.social_available == 0]
    assert len(missing) > 0
    assert np.allclose(missing.social_homophily, 0.5)

