import numpy as np

from ssbm_net.calibration import apply_temperature, expected_calibration_error, fit_temperature


def test_temperature_is_positive():
    logits = np.asarray([-4, -2, -1, 1, 2, 4], dtype=float)
    labels = np.asarray([0, 0, 0, 1, 1, 1], dtype=int)
    temperature = fit_temperature(logits, labels)
    assert temperature > 0
    probability = apply_temperature(logits, temperature)
    assert np.all((probability > 0) & (probability < 1))


def test_ece_bounds():
    labels = np.asarray([0, 0, 1, 1])
    probability = np.asarray([0.1, 0.2, 0.8, 0.9])
    ece = expected_calibration_error(labels, probability, bins=10)
    assert 0 <= ece <= 1

