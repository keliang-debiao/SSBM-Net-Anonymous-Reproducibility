import numpy as np
import pandas as pd

from ssbm_net.audit import audit_rankings_with_brs, exposure_metrics
from ssbm_net.recommenders.rerank import js_divergence


def test_js_divergence_identity():
    distribution = np.asarray([0.2, 0.3, 0.5])
    assert np.isclose(js_divergence(distribution, distribution), 0.0)


def test_exposure_metrics_have_valid_ranges(fixture_data):
    interactions, topics, social = fixture_data
    user = interactions.user_id.iloc[0]
    history = interactions[interactions.user_id == user].item_id.tolist()
    recommended = interactions.item_id.unique()[:10].tolist()
    popularity = interactions.groupby("item_id").size()
    metrics = exposure_metrics(recommended, history, topics, popularity)
    assert all(np.isfinite(value) for value in metrics.values())
    assert 0 <= metrics["topic_entropy"] <= 1
    assert 0 <= metrics["category_coverage"] <= 1
    assert 0 <= metrics["long_tail_ratio"] <= 1


def test_post_exposure_brs_audit_is_finite(fixture_data):
    interactions, topics, social = fixture_data
    users = interactions.user_id.unique()[:5]
    ranked = interactions.item_id.unique()[:8].tolist()
    rankings = {str(user): ranked for user in users}
    audit = audit_rankings_with_brs(rankings, interactions, topics, social)
    assert len(audit) == len(users)
    assert np.isfinite(audit["delta_brs"]).all()
    assert set(audit["high_risk_transition"].unique()).issubset({0, 1})
