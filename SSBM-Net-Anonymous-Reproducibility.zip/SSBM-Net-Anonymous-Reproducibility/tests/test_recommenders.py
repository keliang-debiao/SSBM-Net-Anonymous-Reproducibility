from ssbm_net.recommenders import BPRMFRecommender, LightGCNRecommender, PopularityRecommender


def test_recommenders_return_complete_rankings(fixture_data):
    interactions, topics, social = fixture_data
    user = interactions.user_id.iloc[0]
    items = interactions.item_id.unique()[:10].tolist()
    models = [
        PopularityRecommender(),
        BPRMFRecommender(dimension=8, batch_size=128, epochs=1, seed=2026),
        LightGCNRecommender(dimension=8, layers=1, batch_size=128, epochs=1, seed=2026),
    ]
    for model in models:
        ranking = model.fit(interactions).rank(user, items)
        assert len(ranking) == len(items)
        assert set(ranking) == set(items)
