"""Non-personalized item-popularity ranking."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .base import Recommender


class PopularityRecommender(Recommender):
    def fit(self, interactions: pd.DataFrame):
        self.popularity_ = interactions.groupby("item_id").size().astype(float).to_dict()
        return self

    def score(self, user_id: str, item_ids: list[str]) -> np.ndarray:
        return np.asarray([self.popularity_.get(str(item), 0.0) for item in item_ids], dtype=np.float64)

