"""BPR matrix factorization and sparse LightGCN implementations."""

from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np
import pandas as pd
import torch
from torch import nn

from .base import IdMap, Recommender, validation_ndcg
from ..randomness import set_global_seed


class _EmbeddingModel(nn.Module):
    def __init__(self, users: int, items: int, dimension: int):
        super().__init__()
        self.user = nn.Embedding(users, dimension)
        self.item = nn.Embedding(items, dimension)
        nn.init.normal_(self.user.weight, std=0.1)
        nn.init.normal_(self.item.weight, std=0.1)

    def score(self, users, items):
        return (self.user(users) * self.item(items)).sum(dim=-1)


@dataclass
class BPRMFRecommender(Recommender):
    dimension: int = 64
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    batch_size: int = 2048
    epochs: int = 200
    patience: int = 20
    validation_candidate_size: int = 100
    seed: int = 2026
    device: str = "cpu"
    ips_clip: float | None = None

    def fit(self, interactions: pd.DataFrame, validation: pd.DataFrame | None = None):
        set_global_seed(self.seed)
        self.user_map_ = IdMap(sorted(interactions["user_id"].astype(str).unique()))
        self.item_map_ = IdMap(sorted(interactions["item_id"].astype(str).unique()))
        user_indices = self.user_map_.encode(interactions["user_id"].astype(str))
        item_indices = self.item_map_.encode(interactions["item_id"].astype(str))
        positives = {u: set() for u in range(len(self.user_map_.values))}
        for u, i in zip(user_indices, item_indices):
            positives[int(u)].add(int(i))
        popularity = np.bincount(item_indices, minlength=len(self.item_map_.values)).astype(np.float64)
        propensity = np.maximum(popularity / max(popularity.max(), 1.0), 1e-6)
        all_items = np.arange(len(self.item_map_.values), dtype=np.int64)
        negative_pools = {
            user: np.setdiff1d(all_items, np.fromiter(observed, dtype=np.int64), assume_unique=False)
            for user, observed in positives.items()
        }
        eligible = np.asarray([index for index, user in enumerate(user_indices) if len(negative_pools[int(user)])], dtype=np.int64)
        if not len(eligible):
            raise ValueError("No unobserved items are available for negative sampling")

        self.model_ = _EmbeddingModel(len(self.user_map_.values), len(self.item_map_.values), self.dimension).to(self.device)
        optimizer = torch.optim.Adam(self.model_.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
        rng = np.random.default_rng(self.seed)
        steps = max(1, math.ceil(len(user_indices) / self.batch_size))
        self.training_loss_ = []
        self.validation_ndcg_ = []
        best_metric, best_state, stale = -np.inf, None, 0
        for _ in range(self.epochs):
            epoch_loss = 0.0
            for _ in range(steps):
                selected = rng.choice(eligible, size=min(self.batch_size, len(eligible)), replace=True)
                users = user_indices[selected]
                positive_items = item_indices[selected]
                negative_items = np.asarray([rng.choice(negative_pools[int(user)]) for user in users], dtype=np.int64)
                u = torch.as_tensor(users, dtype=torch.long, device=self.device)
                pos = torch.as_tensor(positive_items, dtype=torch.long, device=self.device)
                neg = torch.as_tensor(negative_items, dtype=torch.long, device=self.device)
                margin = self.model_.score(u, pos) - self.model_.score(u, neg)
                loss_vector = -torch.nn.functional.logsigmoid(margin)
                if self.ips_clip is not None:
                    weights = np.minimum(1.0 / propensity[positive_items], self.ips_clip)
                    loss_vector = loss_vector * torch.as_tensor(weights, dtype=torch.float32, device=self.device)
                loss = loss_vector.mean()
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                epoch_loss += float(loss.detach().cpu())
            self.training_loss_.append(epoch_loss / steps)
            if validation is not None and not validation.empty:
                metric = validation_ndcg(self, interactions, validation, self.validation_candidate_size, self.seed)
                self.validation_ndcg_.append(metric)
                if metric > best_metric + 1e-10:
                    best_metric = metric
                    best_state = {name: value.detach().clone() for name, value in self.model_.state_dict().items()}
                    stale = 0
                else:
                    stale += 1
                    if stale >= self.patience:
                        break
        if best_state is not None:
            self.model_.load_state_dict(best_state)
        return self

    @torch.no_grad()
    def score(self, user_id: str, item_ids: list[str]) -> np.ndarray:
        if str(user_id) not in self.user_map_.to_index:
            return np.zeros(len(item_ids), dtype=np.float64)
        valid = [self.item_map_.to_index.get(str(item), -1) for item in item_ids]
        scores = np.full(len(item_ids), -np.inf, dtype=np.float64)
        positions = [index for index, item in enumerate(valid) if item >= 0]
        if positions:
            user = torch.full((len(positions),), self.user_map_.to_index[str(user_id)], dtype=torch.long, device=self.device)
            item = torch.as_tensor([valid[index] for index in positions], dtype=torch.long, device=self.device)
            values = self.model_.score(user, item).cpu().numpy()
            scores[positions] = values
        return scores


class _LightGCNModel(nn.Module):
    def __init__(self, users: int, items: int, dimension: int, layers: int, adjacency: torch.Tensor):
        super().__init__()
        self.users = users
        self.items = items
        self.layers = layers
        self.embedding = nn.Embedding(users + items, dimension)
        nn.init.normal_(self.embedding.weight, std=0.1)
        self.register_buffer("adjacency", adjacency)

    def propagated(self):
        representations = [self.embedding.weight]
        current = self.embedding.weight
        for _ in range(self.layers):
            current = torch.sparse.mm(self.adjacency, current)
            representations.append(current)
        final = torch.stack(representations, dim=0).mean(dim=0)
        return final[: self.users], final[self.users :]


def _normalized_bipartite_adjacency(user_indices, item_indices, users, items, device):
    left = np.concatenate([user_indices, users + item_indices])
    right = np.concatenate([users + item_indices, user_indices])
    indices = np.vstack([left, right])
    degree = np.bincount(indices[0], minlength=users + items).astype(np.float64)
    values = 1.0 / np.sqrt(np.maximum(degree[indices[0]] * degree[indices[1]], 1.0))
    return torch.sparse_coo_tensor(
        torch.as_tensor(indices, dtype=torch.long, device=device),
        torch.as_tensor(values, dtype=torch.float32, device=device),
        size=(users + items, users + items),
        device=device,
        check_invariants=False,
    ).coalesce()


@dataclass
class LightGCNRecommender(BPRMFRecommender):
    layers: int = 3

    def fit(self, interactions: pd.DataFrame, validation: pd.DataFrame | None = None):
        set_global_seed(self.seed)
        self.user_map_ = IdMap(sorted(interactions["user_id"].astype(str).unique()))
        self.item_map_ = IdMap(sorted(interactions["item_id"].astype(str).unique()))
        user_indices = self.user_map_.encode(interactions["user_id"].astype(str))
        item_indices = self.item_map_.encode(interactions["item_id"].astype(str))
        users, items = len(self.user_map_.values), len(self.item_map_.values)
        adjacency = _normalized_bipartite_adjacency(user_indices, item_indices, users, items, self.device)
        self.model_ = _LightGCNModel(users, items, self.dimension, self.layers, adjacency).to(self.device)
        positives = {u: set() for u in range(users)}
        for u, i in zip(user_indices, item_indices):
            positives[int(u)].add(int(i))
        popularity = np.bincount(item_indices, minlength=items).astype(np.float64)
        propensity = np.maximum(popularity / max(popularity.max(), 1.0), 1e-6)
        all_items = np.arange(items, dtype=np.int64)
        negative_pools = {
            user: np.setdiff1d(all_items, np.fromiter(observed, dtype=np.int64), assume_unique=False)
            for user, observed in positives.items()
        }
        eligible = np.asarray([index for index, user in enumerate(user_indices) if len(negative_pools[int(user)])], dtype=np.int64)
        if not len(eligible):
            raise ValueError("No unobserved items are available for negative sampling")
        optimizer = torch.optim.Adam(self.model_.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
        rng = np.random.default_rng(self.seed)
        steps = max(1, math.ceil(len(user_indices) / self.batch_size))
        self.training_loss_ = []
        self.validation_ndcg_ = []
        best_metric, best_state, stale = -np.inf, None, 0
        for _ in range(self.epochs):
            epoch_loss = 0.0
            for _ in range(steps):
                user_embedding, item_embedding = self.model_.propagated()
                selected = rng.choice(eligible, size=min(self.batch_size, len(eligible)), replace=True)
                batch_users = user_indices[selected]
                positive_items = item_indices[selected]
                negative_items = np.asarray([rng.choice(negative_pools[int(user)]) for user in batch_users], dtype=np.int64)
                u = torch.as_tensor(batch_users, dtype=torch.long, device=self.device)
                pos = torch.as_tensor(positive_items, dtype=torch.long, device=self.device)
                neg = torch.as_tensor(negative_items, dtype=torch.long, device=self.device)
                margin = (user_embedding[u] * item_embedding[pos]).sum(-1) - (user_embedding[u] * item_embedding[neg]).sum(-1)
                loss_vector = -torch.nn.functional.logsigmoid(margin)
                if self.ips_clip is not None:
                    weights = np.minimum(1.0 / propensity[positive_items], self.ips_clip)
                    loss_vector = loss_vector * torch.as_tensor(weights, dtype=torch.float32, device=self.device)
                loss = loss_vector.mean()
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                epoch_loss += float(loss.detach().cpu())
            self.training_loss_.append(epoch_loss / steps)
            if validation is not None and not validation.empty:
                self.user_embedding_, self.item_embedding_ = [tensor.detach() for tensor in self.model_.propagated()]
                metric = validation_ndcg(self, interactions, validation, self.validation_candidate_size, self.seed)
                self.validation_ndcg_.append(metric)
                if metric > best_metric + 1e-10:
                    best_metric = metric
                    best_state = {name: value.detach().clone() for name, value in self.model_.state_dict().items()}
                    stale = 0
                else:
                    stale += 1
                    if stale >= self.patience:
                        break
        if best_state is not None:
            self.model_.load_state_dict(best_state)
        self.user_embedding_, self.item_embedding_ = [tensor.detach() for tensor in self.model_.propagated()]
        return self

    @torch.no_grad()
    def score(self, user_id: str, item_ids: list[str]) -> np.ndarray:
        if str(user_id) not in self.user_map_.to_index:
            return np.zeros(len(item_ids), dtype=np.float64)
        valid = [self.item_map_.to_index.get(str(item), -1) for item in item_ids]
        output = np.full(len(item_ids), -np.inf, dtype=np.float64)
        positions = [index for index, item in enumerate(valid) if item >= 0]
        if positions:
            user = self.user_embedding_[self.user_map_.to_index[str(user_id)]]
            items = self.item_embedding_[torch.as_tensor([valid[index] for index in positions], device=self.device)]
            output[positions] = (items * user).sum(-1).cpu().numpy()
        return output
