"""Distribution-calibrated and xQuAD-style topic reranking."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np


def _normalize_scores(scores):
    scores = np.asarray(scores, dtype=np.float64)
    finite = np.isfinite(scores)
    output = np.zeros_like(scores)
    if finite.any():
        minimum, maximum = scores[finite].min(), scores[finite].max()
        output[finite] = (scores[finite] - minimum) / max(maximum - minimum, 1e-12)
    return output


def js_divergence(left, right, epsilon=1e-12):
    left = np.asarray(left, dtype=np.float64)
    right = np.asarray(right, dtype=np.float64)
    left = left / max(left.sum(), epsilon)
    right = right / max(right.sum(), epsilon)
    middle = 0.5 * (left + right)
    kl_left = np.sum(left * np.log((left + epsilon) / (middle + epsilon)))
    kl_right = np.sum(right * np.log((right + epsilon) / (middle + epsilon)))
    return float(0.5 * (kl_left + kl_right))


@dataclass
class DistributionCalibratedReranker:
    weight: float = 0.20

    def rerank(self, item_ids, relevance_scores, item_vectors, user_profile, k):
        relevance = _normalize_scores(relevance_scores)
        selected = []
        remaining = list(range(len(item_ids)))
        aggregate = np.zeros_like(user_profile, dtype=np.float64)
        while remaining and len(selected) < k:
            best_index, best_value = None, -np.inf
            for candidate in remaining:
                proposed = aggregate + item_vectors[candidate]
                value = (1.0 - self.weight) * relevance[candidate] - self.weight * js_divergence(user_profile, proposed)
                if value > best_value:
                    best_index, best_value = candidate, value
            selected.append(best_index)
            aggregate += item_vectors[best_index]
            remaining.remove(best_index)
        return [item_ids[index] for index in selected]


@dataclass
class XQuADReranker:
    weight: float = 0.25

    def rerank(self, item_ids, relevance_scores, item_vectors, k):
        relevance = _normalize_scores(relevance_scores)
        selected = []
        remaining = list(range(len(item_ids)))
        covered = np.zeros(item_vectors.shape[1], dtype=np.float64)
        while remaining and len(selected) < k:
            best_index, best_value = None, -np.inf
            for candidate in remaining:
                novelty = float(np.sum(item_vectors[candidate] * (1.0 - np.clip(covered, 0.0, 1.0))))
                value = (1.0 - self.weight) * relevance[candidate] + self.weight * novelty
                if value > best_value:
                    best_index, best_value = candidate, value
            selected.append(best_index)
            covered = np.maximum(covered, item_vectors[best_index])
            remaining.remove(best_index)
        return [item_ids[index] for index in selected]

