"""Shared identifier maps, candidate construction, and scoring interface."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class IdMap:
    values: list[str]

    def __post_init__(self):
        self.values = list(map(str, self.values))
        self.to_index = {value: index for index, value in enumerate(self.values)}

    def encode(self, values):
        return np.asarray([self.to_index[str(value)] for value in values], dtype=np.int64)

    def decode(self, indices):
        return [self.values[int(index)] for index in indices]


class Recommender:
    def fit(self, interactions: pd.DataFrame):
        raise NotImplementedError

    def score(self, user_id: str, item_ids: list[str]) -> np.ndarray:
        raise NotImplementedError

    def rank(self, user_id: str, item_ids: list[str]) -> list[str]:
        scores = self.score(str(user_id), list(map(str, item_ids)))
        order = np.argsort(-scores, kind="mergesort")
        return [str(item_ids[index]) for index in order]


def build_candidate_sets(
    train: pd.DataFrame,
    test: pd.DataFrame,
    candidate_size: int,
    seed: int,
) -> dict[str, tuple[str, list[str]]]:
    if candidate_size < 2:
        raise ValueError("candidate_size must be at least two")
    all_items = np.asarray(sorted(train["item_id"].astype(str).unique()))
    histories = train.groupby("user_id")["item_id"].agg(lambda x: set(map(str, x))).to_dict()
    rng = np.random.default_rng(seed)
    candidates = {}
    for user, group in test.sort_values(["user_id", "timestamp", "item_id"]).groupby("user_id", sort=True):
        user = str(user)
        positive = str(group.iloc[0]["item_id"])
        blocked = histories.get(user, set()) | {positive}
        available = all_items[~np.isin(all_items, list(blocked))]
        if len(available) < candidate_size - 1:
            selected = available
        else:
            selected = rng.choice(available, size=candidate_size - 1, replace=False)
        items = np.concatenate([[positive], selected.astype(str)]).tolist()
        candidates[user] = (positive, items)
    return candidates


def validation_ndcg(model, train, validation, candidate_size: int, seed: int, k: int = 20) -> float:
    candidates = build_candidate_sets(train, validation, candidate_size, seed)
    if not candidates:
        return float("nan")
    values = []
    for user, (positive, items) in candidates.items():
        ranked = model.rank(user, items)[:k]
        if positive in ranked:
            values.append(1.0 / np.log2(ranked.index(positive) + 2.0))
        else:
            values.append(0.0)
    return float(np.mean(values))
