"""Compact SASRec implementation for chronological implicit feedback."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd
import torch
from torch import nn

from .base import IdMap, Recommender, validation_ndcg
from ..randomness import set_global_seed


class _SASRecModel(nn.Module):
    def __init__(self, items, dimension, blocks, heads, dropout, max_length):
        super().__init__()
        self.max_length = max_length
        self.item = nn.Embedding(items + 1, dimension, padding_idx=0)
        self.position = nn.Embedding(max_length, dimension)
        layer = nn.TransformerEncoderLayer(
            d_model=dimension,
            nhead=heads,
            dim_feedforward=dimension * 4,
            dropout=dropout,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=blocks)
        self.norm = nn.LayerNorm(dimension)

    def encode(self, sequence):
        length = sequence.shape[1]
        position = torch.arange(length, device=sequence.device).unsqueeze(0)
        x = self.item(sequence) + self.position(position)
        causal = torch.triu(torch.ones(length, length, device=sequence.device, dtype=torch.bool), diagonal=1)
        padding = sequence.eq(0)
        encoded = self.encoder(x, mask=causal, src_key_padding_mask=padding)
        valid_lengths = sequence.ne(0).sum(dim=1).clamp(min=1) - 1
        return self.norm(encoded[torch.arange(len(sequence), device=sequence.device), valid_lengths])


@dataclass
class SASRecRecommender(Recommender):
    dimension: int = 64
    blocks: int = 2
    heads: int = 2
    dropout: float = 0.20
    max_length: int = 100
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4
    batch_size: int = 256
    epochs: int = 200
    patience: int = 20
    validation_candidate_size: int = 100
    seed: int = 2026
    device: str = "cpu"

    def _encode_sequence(self, items):
        encoded = [self.item_map_.to_index[str(item)] + 1 for item in items if str(item) in self.item_map_.to_index]
        encoded = encoded[-self.max_length :]
        return [0] * (self.max_length - len(encoded)) + encoded

    def fit(self, interactions: pd.DataFrame, validation: pd.DataFrame | None = None):
        set_global_seed(self.seed)
        ordered = interactions.sort_values(["user_id", "timestamp", "item_id"], kind="mergesort")
        self.item_map_ = IdMap(sorted(ordered["item_id"].astype(str).unique()))
        self.histories_ = ordered.groupby("user_id")["item_id"].agg(lambda x: list(map(str, x))).to_dict()
        training_rows = []
        for history in self.histories_.values():
            if len(history) >= 2:
                training_rows.append((self._encode_sequence(history[:-1]), self.item_map_.to_index[history[-1]] + 1))
        self.model_ = _SASRecModel(len(self.item_map_.values), self.dimension, self.blocks, self.heads, self.dropout, self.max_length).to(self.device)
        optimizer = torch.optim.Adam(self.model_.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
        rng = np.random.default_rng(self.seed)
        self.training_loss_ = []
        self.validation_ndcg_ = []
        best_metric, best_state, stale = -np.inf, None, 0
        for _ in range(self.epochs):
            rng.shuffle(training_rows)
            losses = []
            for start in range(0, len(training_rows), self.batch_size):
                batch = training_rows[start : start + self.batch_size]
                sequence = torch.as_tensor([row[0] for row in batch], dtype=torch.long, device=self.device)
                target = torch.as_tensor([row[1] for row in batch], dtype=torch.long, device=self.device)
                state = self.model_.encode(sequence)
                logits = state @ self.model_.item.weight[1:].T
                loss = torch.nn.functional.cross_entropy(logits, target - 1)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                losses.append(float(loss.detach().cpu()))
            self.training_loss_.append(float(np.mean(losses)) if losses else 0.0)
            if validation is not None and not validation.empty:
                metric = validation_ndcg(self, interactions, validation, self.validation_candidate_size, self.seed)
                self.validation_ndcg_.append(metric)
                if metric > best_metric + 1e-10:
                    best_metric = metric
                    best_state = {name: value.detach().clone() for name, value in self.model_.state_dict().items()}
                    stale = 0
                else:
                    stale += 1
                    if stale >= self.patience:
                        break
        if best_state is not None:
            self.model_.load_state_dict(best_state)
        return self

    @torch.no_grad()
    def score(self, user_id: str, item_ids: list[str]) -> np.ndarray:
        history = self.histories_.get(str(user_id), [])
        sequence = torch.as_tensor([self._encode_sequence(history)], dtype=torch.long, device=self.device)
        state = self.model_.encode(sequence)[0]
        output = np.full(len(item_ids), -np.inf, dtype=np.float64)
        for position, item in enumerate(item_ids):
            index = self.item_map_.to_index.get(str(item))
            if index is not None:
                output[position] = float((state * self.model_.item.weight[index + 1]).sum().cpu())
        return output
