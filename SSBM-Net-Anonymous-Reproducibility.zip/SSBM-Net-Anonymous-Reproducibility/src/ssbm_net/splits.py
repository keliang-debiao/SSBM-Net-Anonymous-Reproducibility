"""Leakage-controlled user and chronological splitting."""

from __future__ import annotations

import numpy as np
import pandas as pd


def split_users(users, train: float, validation: float, test: float, seed: int):
    if not np.isclose(train + validation + test, 1.0):
        raise ValueError("User split fractions must sum to one")
    users = np.asarray(sorted(map(str, users)))
    rng = np.random.default_rng(seed)
    order = rng.permutation(users)
    n_train = int(np.floor(len(order) * train))
    n_validation = int(np.floor(len(order) * validation))
    return {
        "train": order[:n_train],
        "validation": order[n_train:n_train + n_validation],
        "test": order[n_train + n_validation:],
    }


def chronological_user_split(interactions: pd.DataFrame, early_fraction: float = 0.70):
    if not 0.0 < early_fraction < 1.0:
        raise ValueError("early_fraction must be between zero and one")
    early_parts = []
    future_parts = []
    for _, group in interactions.sort_values(["user_id", "timestamp", "item_id"], kind="mergesort").groupby("user_id", sort=True):
        if len(group) < 2:
            continue
        cut = min(max(int(np.floor(len(group) * early_fraction)), 1), len(group) - 1)
        early_parts.append(group.iloc[:cut])
        future_parts.append(group.iloc[cut:])
    columns = interactions.columns
    early = pd.concat(early_parts, ignore_index=True) if early_parts else pd.DataFrame(columns=columns)
    future = pd.concat(future_parts, ignore_index=True) if future_parts else pd.DataFrame(columns=columns)
    return early, future


def recommendation_split(interactions: pd.DataFrame, train_fraction: float = 0.70, validation_fraction: float = 0.10):
    train_parts, validation_parts, test_parts = [], [], []
    ordered = interactions.sort_values(["user_id", "timestamp", "item_id"], kind="mergesort")
    for _, group in ordered.groupby("user_id", sort=True):
        if len(group) < 3:
            continue
        n = len(group)
        a = min(max(int(np.floor(n * train_fraction)), 1), n - 2)
        b = min(max(int(np.floor(n * (train_fraction + validation_fraction))), a + 1), n - 1)
        train_parts.append(group.iloc[:a])
        validation_parts.append(group.iloc[a:b])
        test_parts.append(group.iloc[b:])
    columns = interactions.columns
    return tuple(
        pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=columns)
        for parts in (train_parts, validation_parts, test_parts)
    )

