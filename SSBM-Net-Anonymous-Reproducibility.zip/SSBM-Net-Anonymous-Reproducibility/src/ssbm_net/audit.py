"""Recommendation-list utility and exposure-risk auditing."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs, high_risk_threshold
from .evaluation import ranking_metrics
from .features import _topic_index, _profile, build_user_features, normalized_entropy
from .recommenders.rerank import js_divergence
from .temporal import long_tail_items, training_popularity


def item_topic_matrix(item_ids, item_topics: pd.DataFrame):
    topics, item_to_vec = _topic_index(item_topics)
    matrix = np.vstack([item_to_vec.get(str(item), np.zeros(len(topics))) for item in item_ids])
    return topics, matrix


def exposure_metrics(
    recommended_items,
    historical_items,
    item_topics: pd.DataFrame,
    popularity: pd.Series,
):
    topics, item_to_vec = _topic_index(item_topics)
    recommendation_profile = _profile(list(map(str, recommended_items)), item_to_vec, len(topics))
    history_profile = _profile(list(map(str, historical_items)), item_to_vec, len(topics))
    tail = long_tail_items(popularity)
    return {
        "topic_entropy": normalized_entropy(recommendation_profile),
        "category_coverage": float(np.count_nonzero(recommendation_profile) / max(len(topics), 1)),
        "long_tail_ratio": float(np.mean([str(item) in tail for item in recommended_items])),
        "js_divergence": js_divergence(history_profile, recommendation_profile),
    }


def evaluate_rankings(rankings, positives, k: int = 20):
    rows = [ranking_metrics(rankings[user], positives[user], k=k) for user in sorted(rankings)]
    frame = pd.DataFrame(rows)
    return {
        "recall_at_20": float(frame["recall"].mean()),
        "ndcg_at_20": float(frame["ndcg"].mean()),
        "hit_at_20": float(frame["hit"].mean()),
    }


def audit_rankings(rankings, train_interactions: pd.DataFrame, item_topics: pd.DataFrame):
    histories = train_interactions.groupby("user_id")["item_id"].agg(list).to_dict()
    popularity = training_popularity(train_interactions)
    rows = []
    for user, ranked_items in rankings.items():
        rows.append({"user_id": str(user), **exposure_metrics(ranked_items, histories.get(str(user), []), item_topics, popularity)})
    return pd.DataFrame(rows)


def append_ranked_exposure(
    train_interactions: pd.DataFrame,
    rankings: dict[str, list[str]],
) -> pd.DataFrame:
    """Append ranked items after each user's observed history without changing signal scale."""
    base = train_interactions.copy()
    timestamp = pd.to_numeric(base["timestamp"], errors="coerce")
    global_last = float(timestamp.max()) if timestamp.notna().any() else float(len(base))
    user_last = (
        base.assign(_time=timestamp)
        .groupby(base["user_id"].astype(str))["_time"]
        .max()
        .to_dict()
    )
    appended = []
    for user in sorted(rankings):
        start = user_last.get(str(user), global_last)
        if not np.isfinite(start):
            start = global_last
        for offset, item in enumerate(rankings[user], start=1):
            appended.append({
                "user_id": str(user),
                "item_id": str(item),
                "timestamp": float(start) + offset,
                "signal": 1.0,
            })
    if not appended:
        return base
    return pd.concat([base, pd.DataFrame(appended)], ignore_index=True)


def audit_rankings_with_brs(
    rankings: dict[str, list[str]],
    train_interactions: pd.DataFrame,
    item_topics: pd.DataFrame,
    social_edges: pd.DataFrame | None = None,
    weights=PRIOR_WEIGHTS,
    high_fraction: float = 0.30,
    dominant_topic_mass: float = 0.80,
    social_missing_value: float = 0.50,
) -> pd.DataFrame:
    """Audit list diversity and recompute BRS after the recommended exposure is appended."""
    exposure = audit_rankings(rankings, train_interactions, item_topics)
    before_raw = build_user_features(
        train_interactions,
        item_topics,
        social_edges,
        dominant_topic_mass=dominant_topic_mass,
        social_missing_value=social_missing_value,
    )
    normalizer = BRSNormalizer().fit(before_raw)
    before = normalizer.transform(before_raw)
    before["brs_before"] = compute_brs(before, weights)
    cutoff = high_risk_threshold(before["brs_before"], high_fraction)

    post_interactions = append_ranked_exposure(train_interactions, rankings)
    after_raw = build_user_features(
        post_interactions,
        item_topics,
        social_edges,
        dominant_topic_mass=dominant_topic_mass,
        social_missing_value=social_missing_value,
    )
    after = normalizer.transform(after_raw)
    after["brs_after"] = compute_brs(after, weights)
    paired = before[["user_id", "brs_before"]].merge(
        after[["user_id", "brs_after"]], on="user_id", validate="one_to_one"
    )
    paired["delta_brs"] = paired["brs_after"] - paired["brs_before"]
    paired["eligible_transition"] = paired["brs_before"] < cutoff
    paired["high_risk_transition"] = (
        paired["eligible_transition"] & (paired["brs_after"] >= cutoff)
    ).astype(int)
    return exposure.merge(paired, on="user_id", how="left", validate="one_to_one")
