"""One-graph social-neighborhood feature enhancement."""

from __future__ import annotations

from collections import defaultdict
import numpy as np
import pandas as pd

from .features import COMPONENT_COLUMNS


def enhance_with_social_neighborhood(
    normalized_features: pd.DataFrame,
    social_edges: pd.DataFrame,
    neutral_value: float = 0.50,
) -> pd.DataFrame:
    indexed = normalized_features.set_index("user_id", drop=False)
    neighbors: dict[str, set[str]] = defaultdict(set)
    for row in social_edges.itertuples(index=False):
        source, target = str(row.source_user_id), str(row.target_user_id)
        if source in indexed.index and target in indexed.index and source != target:
            neighbors[source].add(target)
            neighbors[target].add(source)

    output = normalized_features.copy()
    neighbor_columns = [f"neighbor_{name}" for name in COMPONENT_COLUMNS]
    neighbor_rows = []
    availability = []
    for user in output["user_id"].astype(str):
        valid = sorted(neighbors.get(user, set()))
        if valid:
            matrix = indexed.loc[valid, list(COMPONENT_COLUMNS)].to_numpy(dtype=np.float64)
            neighbor_rows.append(matrix.mean(axis=0))
            availability.append(1)
        else:
            neighbor_rows.append(np.repeat(neutral_value, len(COMPONENT_COLUMNS)))
            availability.append(0)
    output.loc[:, neighbor_columns] = np.vstack(neighbor_rows)
    output["social_available"] = availability
    return output

