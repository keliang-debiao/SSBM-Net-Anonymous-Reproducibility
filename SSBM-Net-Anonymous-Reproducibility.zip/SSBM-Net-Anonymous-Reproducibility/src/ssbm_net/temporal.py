"""Independent future-exposure criteria and future-narrowing score."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .features import _topic_index, _profile, normalized_entropy, user_topic_profiles


FUTURE_COLUMNS = (
    "future_topic_entropy",
    "future_category_coverage",
    "future_long_tail_exposure",
    "dominant_topic_persistence",
)


def training_popularity(interactions: pd.DataFrame) -> pd.Series:
    return interactions.groupby("item_id").size().sort_index()


def long_tail_items(popularity: pd.Series, quantile: float = 0.80) -> set[str]:
    cutoff = float(popularity.quantile(quantile))
    return set(popularity[popularity <= cutoff].index.astype(str))


def compute_future_outcomes(
    early: pd.DataFrame,
    future: pd.DataFrame,
    item_topics: pd.DataFrame,
    popularity_source: pd.DataFrame | None = None,
    dominant_mass: float = 0.80,
) -> pd.DataFrame:
    topics, item_to_vec = _topic_index(item_topics)
    n_topics = len(topics)
    pop = training_popularity(popularity_source if popularity_source is not None else early)
    tail = long_tail_items(pop)
    early_groups = {str(user): group for user, group in early.groupby("user_id", sort=True)}
    rows = []
    for user, group in future.groupby("user_id", sort=True):
        user = str(user)
        if user not in early_groups or len(group) == 0:
            continue
        early_items = early_groups[user]["item_id"].astype(str).tolist()
        future_items = group["item_id"].astype(str).tolist()
        early_profile = _profile(early_items, item_to_vec, n_topics)
        future_profile = _profile(future_items, item_to_vec, n_topics)
        order = np.argsort(early_profile)[::-1]
        cumulative = np.cumsum(early_profile[order])
        stop = int(np.searchsorted(cumulative, dominant_mass, side="left"))
        dominant = order[: stop + 1]
        rows.append({
            "user_id": user,
            "future_topic_entropy": normalized_entropy(future_profile),
            "future_category_coverage": float(np.count_nonzero(future_profile) / max(n_topics, 1)),
            "future_long_tail_exposure": float(np.mean([item in tail for item in future_items])),
            "dominant_topic_persistence": float(future_profile[dominant].sum()),
        })
    return pd.DataFrame(rows)


def future_narrowing_score(outcomes: pd.DataFrame) -> pd.Series:
    required = list(FUTURE_COLUMNS)
    missing = [column for column in required if column not in outcomes.columns]
    if missing:
        raise ValueError(f"Future outcomes missing columns: {missing}")
    score = 0.25 * (
        (1.0 - outcomes["future_topic_entropy"].to_numpy(dtype=float))
        + (1.0 - outcomes["future_category_coverage"].to_numpy(dtype=float))
        + (1.0 - outcomes["future_long_tail_exposure"].to_numpy(dtype=float))
        + outcomes["dominant_topic_persistence"].to_numpy(dtype=float)
    )
    return pd.Series(np.clip(score, 0.0, 1.0), index=outcomes.index, name="future_narrowing_score")

