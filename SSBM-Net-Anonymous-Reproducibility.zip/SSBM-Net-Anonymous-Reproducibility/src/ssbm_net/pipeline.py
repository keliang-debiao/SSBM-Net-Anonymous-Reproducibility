"""End-to-end measurement pipeline with leakage-controlled fitting."""

from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

from .brs import BRSNormalizer, PRIOR_WEIGHTS, compute_brs, high_risk_labels, high_risk_threshold, learn_proxy_weights
from .config import save_yaml_snapshot
from .evaluation import binary_metrics, continuous_metrics, spearman_correlation
from .features import COMPONENT_COLUMNS, build_user_features
from .io import JsonlLogger, load_processed_dataset
from .models import CalibratedEnsemble, make_classifier
from .social import enhance_with_social_neighborhood
from .splits import chronological_user_split, split_users
from .temporal import FUTURE_COLUMNS, compute_future_outcomes, future_narrowing_score


def _subset(frame, users):
    return frame[frame["user_id"].astype(str).isin(set(map(str, users)))].copy()


def _feature_matrix(frame, social=False):
    columns = list(COMPONENT_COLUMNS)
    if social:
        columns += [f"neighbor_{name}" for name in COMPONENT_COLUMNS] + ["social_available"]
    return frame.loc[:, columns].to_numpy(dtype=np.float64)


def _save_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)


def run_study(config, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    save_yaml_snapshot(config, output / "resolved_config.yaml")
    logger = JsonlLogger(output / "run.jsonl")
    interactions, item_topics, social_edges = load_processed_dataset(config["processed_dir"])
    logger.write("data_loaded", interactions=len(interactions), users=int(interactions.user_id.nunique()), items=int(interactions.item_id.nunique()))

    seeds = config["seeds"]
    measurement = config["measurement"]
    split_cfg = config["split"]

    full_features = build_user_features(
        interactions,
        item_topics,
        social_edges,
        component_early_fraction=split_cfg["component_early"],
        dominant_topic_mass=measurement["dominant_topic_mass"],
        social_missing_value=measurement["social_missing_value"],
    )
    full_features.to_csv(output / "user_features_raw.csv", index=False)
    internal_rows = []
    temporal_rows = []
    temporal_continuous_rows = []
    learned_rows = []

    early_interactions, future_interactions = chronological_user_split(interactions, split_cfg["history_early"])
    early_features = build_user_features(
        early_interactions,
        item_topics,
        social_edges,
        component_early_fraction=split_cfg["component_early"],
        dominant_topic_mass=measurement["dominant_topic_mass"],
        social_missing_value=measurement["social_missing_value"],
    )
    future = compute_future_outcomes(early_interactions, future_interactions, item_topics, popularity_source=early_interactions)
    future["future_narrowing_score"] = future_narrowing_score(future)
    temporal_base = early_features.merge(future, on="user_id", how="inner", validate="one_to_one")

    for seed in seeds:
        users = split_users(full_features.user_id, split_cfg["user_train"], split_cfg["user_validation"], split_cfg["user_test"], seed)
        train_raw = _subset(full_features, users["train"])
        validation_raw = _subset(full_features, users["validation"])
        test_raw = _subset(full_features, users["test"])
        normalizer = BRSNormalizer().fit(train_raw)
        train = normalizer.transform(train_raw)
        validation = normalizer.transform(validation_raw)
        test = normalizer.transform(test_raw)
        train["brs"] = compute_brs(train, PRIOR_WEIGHTS)
        validation["brs"] = compute_brs(validation, PRIOR_WEIGHTS)
        test["brs"] = compute_brs(test, PRIOR_WEIGHTS)
        threshold = high_risk_threshold(train.brs, measurement["high_risk_fraction"])
        train_y = high_risk_labels(train.brs, threshold)
        validation_y = high_risk_labels(validation.brs, threshold)
        test_y = high_risk_labels(test.brs, threshold)

        for name in ["logistic_regression", "random_forest", "extra_trees", "gradient_boosting", "mlp"]:
            model = make_classifier(name, seed)
            model.fit(_feature_matrix(train), train_y)
            probability = model.predict_proba(_feature_matrix(test))[:, 1]
            row = {"seed": seed, "model": name, **binary_metrics(test_y, probability, bins=config["calibration"]["ece_bins"])}
            row["brs_mae"] = float(np.mean(np.abs(probability - test.brs.to_numpy())))
            internal_rows.append(row)

        ensemble = CalibratedEnsemble(members=config["calibration"]["ensemble_members"], seed=seed)
        ensemble.fit(_feature_matrix(train), train_y, _feature_matrix(validation), validation_y)
        probability = ensemble.predict_proba(_feature_matrix(test))[:, 1]
        internal_rows.append({"seed": seed, "model": "ssbm_calibrated", **binary_metrics(test_y, probability), "brs_mae": float(np.mean(np.abs(probability - test.brs)))})

        social_train = enhance_with_social_neighborhood(train, social_edges, measurement["social_missing_value"])
        social_validation = enhance_with_social_neighborhood(validation, social_edges, measurement["social_missing_value"])
        social_test = enhance_with_social_neighborhood(test, social_edges, measurement["social_missing_value"])
        social_model = CalibratedEnsemble(members=config["calibration"]["ensemble_members"], seed=seed)
        social_model.fit(_feature_matrix(social_train, True), train_y, _feature_matrix(social_validation, True), validation_y)
        probability = social_model.predict_proba(_feature_matrix(social_test, True))[:, 1]
        internal_rows.append({"seed": seed, "model": "ssbm_social_calibrated", **binary_metrics(test_y, probability), "brs_mae": float(np.mean(np.abs(probability - test.brs)))})

        temporal_users = split_users(temporal_base.user_id, split_cfg["user_train"], split_cfg["user_validation"], split_cfg["user_test"], seed)
        tr_raw = _subset(temporal_base, temporal_users["train"])
        va_raw = _subset(temporal_base, temporal_users["validation"])
        te_raw = _subset(temporal_base, temporal_users["test"])
        temporal_normalizer = BRSNormalizer().fit(tr_raw)
        tr = temporal_normalizer.transform(tr_raw)
        va = temporal_normalizer.transform(va_raw)
        te = temporal_normalizer.transform(te_raw)
        weights = learn_proxy_weights(tr, tr["future_narrowing_score"], measurement["proxy_ridge"])
        learned_rows.append({"seed": seed, **dict(zip(COMPONENT_COLUMNS, weights))})
        tr_score, va_score, te_score = compute_brs(tr, weights), compute_brs(va, weights), compute_brs(te, weights)
        prior_test_score = compute_brs(te, PRIOR_WEIGHTS)
        for criterion in FUTURE_COLUMNS:
            regressor = LinearRegression().fit(
                compute_brs(tr, PRIOR_WEIGHTS).to_numpy().reshape(-1, 1), tr[criterion]
            )
            prediction = regressor.predict(prior_test_score.to_numpy().reshape(-1, 1))
            row = {
                "seed": seed,
                "criterion": criterion,
                **continuous_metrics(te[criterion], prediction),
            }
            row["spearman_rho"] = spearman_correlation(te[criterion], prior_test_score)
            temporal_continuous_rows.append(row)
        criterion_threshold = high_risk_threshold(tr["future_narrowing_score"], measurement["high_risk_fraction"])
        tr_y = high_risk_labels(tr["future_narrowing_score"], criterion_threshold)
        va_y = high_risk_labels(va["future_narrowing_score"], criterion_threshold)
        te_y = high_risk_labels(te["future_narrowing_score"], criterion_threshold)
        score_variants = {
            "semantic_homogeneity": te["semantic_homogeneity"],
            "topic_entropy": te["topic_concentration"],
            "gini_concentration": te["gini_concentration"],
            "equal_weight_brs": compute_brs(te, np.ones(len(COMPONENT_COLUMNS))),
            "prior_weight_brs": prior_test_score,
            "proxy_learned_brs": te_score,
        }
        for model_name, model_score in score_variants.items():
            temporal_rows.append({
                "seed": seed,
                "model": model_name,
                **binary_metrics(te_y, model_score, bins=config["calibration"]["ece_bins"]),
                **continuous_metrics(te["future_narrowing_score"], model_score),
            })
        temporal_model = CalibratedEnsemble(members=config["calibration"]["ensemble_members"], seed=seed)
        temporal_model.fit(_feature_matrix(tr), tr_y, _feature_matrix(va), va_y)
        temporal_probability = temporal_model.predict_proba(_feature_matrix(te))[:, 1]
        temporal_rows.append({"seed": seed, "model": "ssbm_calibrated", **binary_metrics(te_y, temporal_probability, bins=config["calibration"]["ece_bins"])})
        logger.write("seed_complete", seed=seed, internal_test_users=len(test), temporal_test_users=len(te))

    pd.DataFrame(internal_rows).to_csv(output / "internal_metrics_by_seed.csv", index=False)
    pd.DataFrame(temporal_rows).to_csv(output / "temporal_metrics_by_seed.csv", index=False)
    pd.DataFrame(temporal_continuous_rows).to_csv(output / "temporal_continuous_by_seed.csv", index=False)
    pd.DataFrame(learned_rows).to_csv(output / "proxy_weights_by_seed.csv", index=False)
    temporal_base.to_csv(output / "temporal_user_matrix.csv", index=False)
    logger.write("run_complete", seeds=len(seeds))
    return {"internal_rows": len(internal_rows), "temporal_rows": len(temporal_rows)}
