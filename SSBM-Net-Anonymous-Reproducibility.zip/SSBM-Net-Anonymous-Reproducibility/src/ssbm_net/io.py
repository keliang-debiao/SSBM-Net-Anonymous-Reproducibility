"""Input contracts, hashing, and run-record utilities."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
from typing import Any

import pandas as pd


INTERACTION_COLUMNS = ("user_id", "item_id", "timestamp", "signal")
TOPIC_COLUMNS = ("item_id", "topic_id", "weight")
SOCIAL_COLUMNS = ("source_user_id", "target_user_id")


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _read_required(path: Path, required: tuple[str, ...]) -> pd.DataFrame:
    frame = pd.read_csv(path)
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ValueError(f"{path} is missing required columns: {missing}")
    return frame.loc[:, list(required)].copy()


def load_processed_dataset(processed_dir: str | Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    root = Path(processed_dir)
    interactions = _read_required(root / "interactions.csv", INTERACTION_COLUMNS)
    topics = _read_required(root / "item_topics.csv", TOPIC_COLUMNS)
    social_path = root / "social_edges.csv"
    if social_path.exists():
        social = _read_required(social_path, SOCIAL_COLUMNS)
    else:
        social = pd.DataFrame(columns=SOCIAL_COLUMNS)
    interactions["user_id"] = interactions["user_id"].astype(str)
    interactions["item_id"] = interactions["item_id"].astype(str)
    topics["item_id"] = topics["item_id"].astype(str)
    topics["topic_id"] = topics["topic_id"].astype(str)
    social["source_user_id"] = social["source_user_id"].astype(str)
    social["target_user_id"] = social["target_user_id"].astype(str)
    interactions = interactions.sort_values(["user_id", "timestamp", "item_id"], kind="mergesort")
    return interactions, topics, social


class JsonlLogger:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def write(self, event: str, **payload: Any) -> None:
        record = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "event": event,
            **payload,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, sort_keys=True) + "\n")


def write_manifest(path: str | Path, payload: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"created_utc": datetime.now(timezone.utc).isoformat(), **payload}
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)

