"""Construction of the six interpretable user-level measurement components."""

from __future__ import annotations

from collections import defaultdict
import math
import numpy as np
import pandas as pd


COMPONENT_COLUMNS = (
    "semantic_homogeneity",
    "social_homophily",
    "topic_concentration",
    "interest_convergence",
    "low_cross_topic_exposure",
    "evidence_insufficiency",
)


def _topic_index(item_topics: pd.DataFrame):
    topics = sorted(item_topics["topic_id"].astype(str).unique())
    items = sorted(item_topics["item_id"].astype(str).unique())
    topic_to_idx = {topic: index for index, topic in enumerate(topics)}
    item_to_vec = {item: np.zeros(len(topics), dtype=np.float64) for item in items}
    for row in item_topics.itertuples(index=False):
        item_to_vec[str(row.item_id)][topic_to_idx[str(row.topic_id)]] += float(row.weight)
    for item, vector in item_to_vec.items():
        total = vector.sum()
        if total > 0:
            item_to_vec[item] = vector / total
    return topics, item_to_vec


def _profile(items, item_to_vec, n_topics):
    vector = np.zeros(n_topics, dtype=np.float64)
    for item in items:
        vector += item_to_vec.get(str(item), 0.0)
    total = vector.sum()
    return vector / total if total > 0 else vector


def normalized_entropy(profile: np.ndarray, epsilon: float = 1e-12) -> float:
    active_dimension = len(profile)
    if active_dimension <= 1 or profile.sum() <= 0:
        return 0.0
    return float(-(profile * np.log(profile + epsilon)).sum() / np.log(active_dimension))


def topic_concentration(profile: np.ndarray) -> float:
    return float(1.0 - normalized_entropy(profile))


def gini_concentration(profile: np.ndarray) -> float:
    values = np.asarray(profile, dtype=np.float64)
    if len(values) <= 1 or values.sum() <= 0:
        return 0.0
    ordered = np.sort(values)
    indices = np.arange(1, len(ordered) + 1, dtype=np.float64)
    gini = (2.0 * np.sum(indices * ordered) / (len(ordered) * ordered.sum())) - (len(ordered) + 1.0) / len(ordered)
    return float(np.clip(gini, 0.0, 1.0))


def semantic_homogeneity(items, item_to_vec) -> float:
    normalized = []
    for item in items:
        vector = np.asarray(item_to_vec.get(str(item), []), dtype=np.float64)
        norm = np.linalg.norm(vector)
        if norm > 0:
            normalized.append(vector / norm)
    n = len(normalized)
    if n < 2:
        return 0.0
    matrix = np.vstack(normalized)
    sum_vector = matrix.sum(axis=0)
    pair_sum_twice = float(sum_vector @ sum_vector - n)
    return float(np.clip(pair_sum_twice / (n * (n - 1)), 0.0, 1.0))


def low_cross_topic_exposure(profile: np.ndarray, cumulative_mass: float = 0.80) -> float:
    if profile.sum() <= 0:
        return 0.0
    sorted_mass = np.sort(profile)[::-1]
    cumulative = np.cumsum(sorted_mass)
    index = int(np.searchsorted(cumulative, cumulative_mass, side="left"))
    return float(sorted_mass[: index + 1].sum())


def cosine(left: np.ndarray, right: np.ndarray) -> float:
    denominator = np.linalg.norm(left) * np.linalg.norm(right)
    if denominator <= 0:
        return 0.0
    return float(np.clip(np.dot(left, right) / denominator, -1.0, 1.0))


def build_user_features(
    interactions: pd.DataFrame,
    item_topics: pd.DataFrame,
    social_edges: pd.DataFrame | None = None,
    component_early_fraction: float = 0.50,
    dominant_topic_mass: float = 0.80,
    social_missing_value: float = 0.50,
) -> pd.DataFrame:
    topics, item_to_vec = _topic_index(item_topics)
    n_topics = len(topics)
    ordered = interactions.sort_values(["user_id", "timestamp", "item_id"], kind="mergesort")
    profiles: dict[str, np.ndarray] = {}
    user_items: dict[str, list[str]] = {}
    temporal_convergence: dict[str, float] = {}
    for user, group in ordered.groupby("user_id", sort=True):
        user = str(user)
        items = group["item_id"].astype(str).tolist()
        user_items[user] = items
        profiles[user] = _profile(items, item_to_vec, n_topics)
        if len(items) < 2:
            temporal_convergence[user] = 0.0
        else:
            cut = min(max(int(math.floor(len(items) * component_early_fraction)), 1), len(items) - 1)
            early_profile = _profile(items[:cut], item_to_vec, n_topics)
            late_profile = _profile(items[cut:], item_to_vec, n_topics)
            temporal_convergence[user] = max(0.0, topic_concentration(late_profile) - topic_concentration(early_profile))

    neighbors: dict[str, set[str]] = defaultdict(set)
    if social_edges is not None and not social_edges.empty:
        for row in social_edges.itertuples(index=False):
            source, target = str(row.source_user_id), str(row.target_user_id)
            if source in profiles and target in profiles and source != target:
                neighbors[source].add(target)
                neighbors[target].add(source)

    rows = []
    for user in sorted(profiles):
        profile = profiles[user]
        valid_neighbors = sorted(neighbors.get(user, set()))
        if valid_neighbors:
            social_homophily = float(np.mean([cosine(profile, profiles[v]) for v in valid_neighbors]))
            social_available = 1
        else:
            social_homophily = float(social_missing_value)
            social_available = 0
        items = user_items[user]
        rows.append({
            "user_id": user,
            "semantic_homogeneity": semantic_homogeneity(items, item_to_vec),
            "social_homophily": social_homophily,
            "topic_concentration": topic_concentration(profile),
            "gini_concentration": gini_concentration(profile),
            "interest_convergence": temporal_convergence[user],
            "low_cross_topic_exposure": low_cross_topic_exposure(profile, dominant_topic_mass),
            "evidence_insufficiency": 1.0 / math.sqrt(len(items) + 1e-12),
            "social_available": social_available,
            "social_degree": len(valid_neighbors),
            "history_length": len(items),
        })
    return pd.DataFrame(rows)


def user_topic_profiles(interactions: pd.DataFrame, item_topics: pd.DataFrame) -> tuple[list[str], dict[str, np.ndarray]]:
    topics, item_to_vec = _topic_index(item_topics)
    profiles = {}
    for user, group in interactions.groupby("user_id", sort=True):
        profiles[str(user)] = _profile(group["item_id"].astype(str).tolist(), item_to_vec, len(topics))
    return topics, profiles
