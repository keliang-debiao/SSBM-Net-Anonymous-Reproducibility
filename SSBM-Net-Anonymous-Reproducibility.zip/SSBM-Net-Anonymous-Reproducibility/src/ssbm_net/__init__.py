"""SSBM-Net measurement, validation, and recommendation auditing."""

from .brs import COMPONENTS, PRIOR_WEIGHTS, BRSNormalizer, compute_brs, learn_proxy_weights
from .features import build_user_features

__all__ = [
    "COMPONENTS",
    "PRIOR_WEIGHTS",
    "BRSNormalizer",
    "compute_brs",
    "learn_proxy_weights",
    "build_user_features",
]

__version__ = "1.0.0"

