"""Deterministic random-state handling."""

from __future__ import annotations

import os
import random
import numpy as np


DEFAULT_SEEDS = (2026, 42, 3407, 2024, 2025)


def set_global_seed(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.use_deterministic_algorithms(True, warn_only=True)
    except ImportError:
        pass

