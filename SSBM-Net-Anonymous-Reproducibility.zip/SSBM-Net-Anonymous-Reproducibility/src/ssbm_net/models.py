"""Internal consistency and temporal-criterion estimators."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

from .calibration import apply_temperature, fit_temperature, logits_from_probabilities


def make_classifier(name: str, seed: int):
    if name == "logistic_regression":
        return LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)
    if name == "random_forest":
        return RandomForestClassifier(n_estimators=400, min_samples_leaf=2, class_weight="balanced", n_jobs=-1, random_state=seed)
    if name == "extra_trees":
        return ExtraTreesClassifier(n_estimators=400, min_samples_leaf=2, class_weight="balanced", n_jobs=-1, random_state=seed)
    if name == "gradient_boosting":
        return GradientBoostingClassifier(n_estimators=200, learning_rate=0.05, max_depth=3, random_state=seed)
    if name == "mlp":
        return MLPClassifier(hidden_layer_sizes=(64, 32), alpha=1e-4, max_iter=500, early_stopping=True, random_state=seed)
    raise KeyError(f"Unknown classifier: {name}")


@dataclass
class CalibratedEnsemble:
    base_name: str = "mlp"
    members: int = 5
    seed: int = 2026

    def fit(self, train_x, train_y, validation_x, validation_y):
        self.models_ = []
        self.temperatures_ = []
        for member in range(self.members):
            model = make_classifier(self.base_name, self.seed + member)
            model.fit(train_x, train_y)
            validation_probability = model.predict_proba(validation_x)[:, 1]
            temperature = fit_temperature(logits_from_probabilities(validation_probability), validation_y)
            self.models_.append(model)
            self.temperatures_.append(temperature)
        return self

    def predict_proba(self, features):
        calibrated = []
        for model, temperature in zip(self.models_, self.temperatures_):
            raw = model.predict_proba(features)[:, 1]
            calibrated.append(apply_temperature(logits_from_probabilities(raw), temperature))
        positive = np.mean(calibrated, axis=0)
        return np.column_stack([1.0 - positive, positive])

