"""Classification, regression, ranking, and statistical evaluation."""

from __future__ import annotations

import math
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
    roc_auc_score,
)

from .calibration import expected_calibration_error


def spearman_correlation(left, right) -> float:
    left = np.asarray(left, dtype=float)
    right = np.asarray(right, dtype=float)
    if len(left) == 0 or np.all(left == left[0]) or np.all(right == right[0]):
        return 0.0
    return float(spearmanr(left, right).statistic)


def binary_metrics(labels, probabilities, threshold: float = 0.50, bins: int = 10):
    labels = np.asarray(labels, dtype=int)
    probabilities = np.asarray(probabilities, dtype=float)
    predictions = (probabilities >= threshold).astype(int)
    return {
        "accuracy": float(accuracy_score(labels, predictions)),
        "macro_f1": float(f1_score(labels, predictions, average="macro")),
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "pr_auc": float(average_precision_score(labels, probabilities)),
        "brier": float(brier_score_loss(labels, probabilities)),
        "ece": expected_calibration_error(labels, probabilities, bins=bins),
    }


def continuous_metrics(target, prediction):
    target = np.asarray(target, dtype=float)
    prediction = np.asarray(prediction, dtype=float)
    rho = spearman_correlation(target, prediction)
    return {
        "spearman_rho": rho,
        "r2": float(r2_score(target, prediction)),
        "mae": float(mean_absolute_error(target, prediction)),
        "rmse": float(math.sqrt(mean_squared_error(target, prediction))),
    }


def paired_bootstrap_difference(left, right, metric, resamples: int, seed: int):
    left = np.asarray(left)
    right = np.asarray(right)
    if len(left) != len(right):
        raise ValueError("Paired arrays must have equal length")
    rng = np.random.default_rng(seed)
    differences = np.empty(resamples, dtype=float)
    for index in range(resamples):
        selected = rng.integers(0, len(left), len(left))
        differences[index] = metric(left[selected]) - metric(right[selected])
    return {
        "difference": float(metric(left) - metric(right)),
        "ci_low": float(np.quantile(differences, 0.025)),
        "ci_high": float(np.quantile(differences, 0.975)),
        "two_sided_p": float(2.0 * min(np.mean(differences <= 0), np.mean(differences >= 0))),
    }


def ranking_metrics(ranked_items, positive_item, k: int = 20):
    top = list(ranked_items)[:k]
    hit = float(positive_item in top)
    if not hit:
        return {"recall": 0.0, "ndcg": 0.0, "hit": 0.0}
    rank = top.index(positive_item) + 1
    return {"recall": 1.0, "ndcg": float(1.0 / np.log2(rank + 1)), "hit": 1.0}
