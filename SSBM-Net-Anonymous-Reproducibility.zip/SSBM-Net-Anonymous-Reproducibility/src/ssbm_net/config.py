"""YAML configuration loading with base-file inheritance."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any
import yaml


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config(path: str | Path) -> dict[str, Any]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as handle:
        cfg = yaml.safe_load(handle) or {}
    default_ref = cfg.pop("defaults", None)
    if default_ref:
        default_path = (path.parent / default_ref).resolve()
        cfg = _deep_merge(load_config(default_path), cfg)
    return cfg


def save_yaml_snapshot(config: dict[str, Any], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(config, handle, sort_keys=True, allow_unicode=True)

