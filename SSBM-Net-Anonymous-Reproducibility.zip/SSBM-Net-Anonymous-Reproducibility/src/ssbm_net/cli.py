"""Command-line entry point for the main SSBM-Net study."""

from __future__ import annotations

import argparse

from .config import load_config
from .pipeline import run_study


def main():
    parser = argparse.ArgumentParser(prog="ssbm-net")
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    run_study(load_config(args.config), args.output_dir)


if __name__ == "__main__":
    main()
