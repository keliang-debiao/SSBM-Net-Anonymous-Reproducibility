"""Temperature scaling and expected calibration error."""

from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar


def sigmoid(values):
    values = np.asarray(values, dtype=np.float64)
    positive = values >= 0
    output = np.empty_like(values)
    output[positive] = 1.0 / (1.0 + np.exp(-values[positive]))
    exp_values = np.exp(values[~positive])
    output[~positive] = exp_values / (1.0 + exp_values)
    return output


def logits_from_probabilities(probabilities, epsilon: float = 1e-8):
    probabilities = np.clip(np.asarray(probabilities, dtype=np.float64), epsilon, 1.0 - epsilon)
    return np.log(probabilities / (1.0 - probabilities))


def binary_nll(labels, probabilities, epsilon: float = 1e-12) -> float:
    labels = np.asarray(labels, dtype=np.float64)
    probabilities = np.clip(np.asarray(probabilities, dtype=np.float64), epsilon, 1.0 - epsilon)
    return float(-np.mean(labels * np.log(probabilities) + (1.0 - labels) * np.log(1.0 - probabilities)))


def fit_temperature(logits, labels) -> float:
    logits = np.asarray(logits, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.float64)

    def objective(log_temperature):
        temperature = np.exp(log_temperature)
        return binary_nll(labels, sigmoid(logits / temperature))

    result = minimize_scalar(objective, bounds=(-4.0, 4.0), method="bounded")
    if not result.success:
        raise RuntimeError("Temperature optimization failed")
    return float(np.exp(result.x))


def apply_temperature(logits, temperature: float, epsilon: float = 1e-12):
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    probabilities = sigmoid(np.asarray(logits, dtype=np.float64) / temperature)
    return np.clip(probabilities, epsilon, 1.0 - epsilon)


def expected_calibration_error(labels, probabilities, bins: int = 10) -> float:
    labels = np.asarray(labels, dtype=np.float64)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = len(labels)
    ece = 0.0
    for index in range(bins):
        lower, upper = edges[index], edges[index + 1]
        if index == bins - 1:
            mask = (probabilities >= lower) & (probabilities <= upper)
        else:
            mask = (probabilities >= lower) & (probabilities < upper)
        if mask.any():
            accuracy = labels[mask].mean()
            confidence = probabilities[mask].mean()
            ece += mask.mean() * abs(accuracy - confidence)
    return float(ece)
