"""Training-only normalization, BRS construction, and proxy-weight learning."""

from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .features import COMPONENT_COLUMNS


COMPONENTS = COMPONENT_COLUMNS
PRIOR_WEIGHTS = np.asarray([0.22, 0.18, 0.20, 0.16, 0.16, 0.08], dtype=np.float64)


@dataclass
class BRSNormalizer:
    minimum: np.ndarray | None = None
    maximum: np.ndarray | None = None
    epsilon: float = 1e-12

    def fit(self, features: pd.DataFrame) -> "BRSNormalizer":
        values = features.loc[:, COMPONENTS].to_numpy(dtype=np.float64)
        self.minimum = np.nanmin(values, axis=0)
        self.maximum = np.nanmax(values, axis=0)
        return self

    def transform(self, features: pd.DataFrame) -> pd.DataFrame:
        if self.minimum is None or self.maximum is None:
            raise RuntimeError("BRSNormalizer must be fitted before transform")
        values = features.loc[:, COMPONENTS].to_numpy(dtype=np.float64)
        denominator = self.maximum - self.minimum
        denominator = np.where(np.abs(denominator) < self.epsilon, 1.0, denominator)
        normalized = np.clip((values - self.minimum) / denominator, 0.0, 1.0)
        result = features.copy()
        result.loc[:, COMPONENTS] = normalized
        return result

    def fit_transform(self, features: pd.DataFrame) -> pd.DataFrame:
        return self.fit(features).transform(features)


def validate_weights(weights) -> np.ndarray:
    weights = np.asarray(weights, dtype=np.float64)
    if weights.shape != (len(COMPONENTS),):
        raise ValueError(f"Expected {len(COMPONENTS)} weights")
    if np.any(weights < -1e-12):
        raise ValueError("Weights must be non-negative")
    total = weights.sum()
    if total <= 0:
        raise ValueError("Weights must have positive mass")
    return weights / total


def compute_brs(normalized_features: pd.DataFrame, weights=PRIOR_WEIGHTS) -> pd.Series:
    weights = validate_weights(weights)
    values = normalized_features.loc[:, COMPONENTS].to_numpy(dtype=np.float64)
    return pd.Series(values @ weights, index=normalized_features.index, name="brs")


def high_risk_threshold(training_brs, high_fraction: float = 0.30) -> float:
    if not 0 < high_fraction < 1:
        raise ValueError("high_fraction must be between zero and one")
    return float(np.quantile(np.asarray(training_brs, dtype=np.float64), 1.0 - high_fraction))


def high_risk_labels(brs, threshold: float) -> np.ndarray:
    return (np.asarray(brs, dtype=np.float64) >= float(threshold)).astype(np.int64)


def learn_proxy_weights(normalized_features: pd.DataFrame, target, ridge: float = 1e-3) -> np.ndarray:
    matrix = normalized_features.loc[:, COMPONENTS].to_numpy(dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    if matrix.shape[0] != target.shape[0]:
        raise ValueError("Features and target must contain the same users")

    def objective(weights):
        residual = target - matrix @ weights
        return float(residual @ residual + ridge * (weights @ weights))

    solution = minimize(
        objective,
        x0=np.repeat(1.0 / len(COMPONENTS), len(COMPONENTS)),
        bounds=[(0.0, 1.0)] * len(COMPONENTS),
        constraints=[{"type": "eq", "fun": lambda w: float(w.sum() - 1.0)}],
        method="SLSQP",
        options={"maxiter": 2000, "ftol": 1e-12},
    )
    if not solution.success:
        raise RuntimeError(f"Proxy-weight optimization failed: {solution.message}")
    return validate_weights(solution.x)

